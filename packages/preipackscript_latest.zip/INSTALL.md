# Installation Guide

## PackScript + Ducky Installation

This guide will help you install PackScript and the Ducky package manager.

## Prerequisites

- Python 3.7 or higher
- Windows, macOS, or Linux
- 50 MB free disk space

## Installation Methods

### Method 1: Automated Installer (Recommended)

1. **Download the installer**
   ```bash
   python installer/install.py
   ```

2. **The installer will:**
   - Download Ducky from the official repository
   - Extract it to your home directory
   - Configure environment variables
   - Add tools to your PATH

3. **Verify installation:**
   ```bash
   pks --help
   ducky --help
   ```

### Method 2: Manual Installation

#### Step 1: Extract files

```bash
mkdir ~/.packscript
cd ~/.packscript
```

#### Step 2: Copy PackScript

```bash
cp -r packscript/* ~/.packscript/
```

#### Step 3: Download Ducky

```bash
wget https://raw.githubusercontent.com/kvxnomxyz/pks-rd/packages/ducky.zip.acpg
unzip ducky.zip.acpg -d ~/.packscript/ducky
```

#### Step 4: Add to PATH

**Windows:**
1. Right-click "This PC" → Properties
2. Advanced system settings → Environment Variables
3. Click "New" under User variables
4. Variable name: `PATH`
5. Variable value: `C:\Users\YourName\.packscript\bin`

**Linux/macOS:**
```bash
echo 'export PATH="$HOME/.packscript/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

## Verification

### Check PackScript

```bash
pks --help
```

Expected output:
```
usage: pks [-h] [-o OUTPUT] [-v] source

PackScript Compiler - Compile PackScript to Java
...
```

### Check Ducky

```bash
ducky info
```

This should display available packages from the repository.

## First Use

### Compile a PackScript file

Create `hello.pks`:
```packscript
#init
modname(Test)
modver(1.0.0)
overridegamefiles(false)

#script
log.print("Hello PackScript!")
```

Compile it:
```bash
pks hello.pks
```

This creates `hello.java`.

### Install a Package

```bash
ducky install easylog
ducky list
```

## Troubleshooting

### "pks command not found"

**Windows:**
- Restart your terminal or IDE
- Verify PATH includes `C:\Users\YourName\.packscript\bin`

**Linux/macOS:**
```bash
source ~/.bashrc
which pks
```

### "ducky command not found"

Same as above. Also verify:

```bash
ls ~/.packscript/ducky/bin/
```

### Python not found

Install Python 3.7+ from [python.org](https://www.python.org)

Verify:
```bash
python --version
```

### Repository connection failed

Check your internet connection:

```bash
ping raw.githubusercontent.com
```

If blocked, configure a proxy or use a custom repository.

### Disk space issues

The installer needs about 50 MB. Check available space:

**Windows:**
```bash
wmic logicaldisk get name,freespace
```

**Linux/macOS:**
```bash
df -h
```

## Uninstallation

### Windows

1. Delete `C:\Users\YourName\.packscript`
2. Remove from PATH environment variable

### Linux/macOS

```bash
rm -rf ~/.packscript
```

## Updating

To update to the latest version:

```bash
python installer/install.py
```

This will download and install the latest Ducky.

## Advanced Configuration

### Custom Package Repository

Set the repository URL:

**Windows:**
```bash
setx DUCKY_REPO https://your-repo-url/packages.json
```

**Linux/macOS:**
```bash
echo 'export DUCKY_REPO=https://your-repo-url/packages.json' >> ~/.bashrc
```

### Custom Install Location

Edit the installer and change `install_dir`:

```python
self.install_dir = "/custom/path"
```

## Getting Started

1. **Learn the language:** Read [LANGUAGE.md](LANGUAGE.md)
2. **Explore examples:** Check the `examples/` folder
3. **Use packages:** `ducky install easylog`
4. **Create your mod:** Start with a simple .pks file

## Need Help?

- Review the examples in the `examples/` folder
- Check [LANGUAGE.md](LANGUAGE.md) for syntax help
- See [DUCKY.md](DUCKY.md) for package manager help
- Visit the GitHub repository for support

---

Happy modding! 🚀

# RawPKS - Real-Time PackScript Development Tool

## Overview

**RawPKS (rpks)** is a development tool that loads and executes raw PackScript (`.pks`) files in real-time with automatic hot-reloading. Perfect for rapid development, testing, and learning!

## Key Features

✨ **Real-Time Execution** - Run scripts instantly without compilation
🔄 **Hot Reload** - Auto-reload when you save files
⚡ **Quick Iteration** - Develop and test rapidly
🔍 **File Watching** - Monitor directories for changes
📊 **Live Variables** - See variable state in real-time
🐛 **Development Tool** - Perfect for debugging and prototyping

## Installation

```bash
ducky install rpks
```

## Quick Start

### Start Real-Time Loader

```bash
rpks start
```

This watches `~/.packscript/scripts/` and auto-executes any `.pks` files.

### Run a Single Script

```bash
rpks run mymod.pks
```

### Watch Custom Directory

```bash
rpks start -d ./my-scripts
```

## Usage Guide

### 1. Create a Script

Create `~/.packscript/scripts/hello.pks`:

```packscript
#init
modname(HelloRaw)
modver(1.0.0)
overridegamefiles(false)

#script

log.print("Hello from RawPKS!")
setvar(x, 42)
log.print("Value: ")
log.print(x)
```

### 2. Execute It

```bash
rpks run hello.pks
```

Output:
```
Hello from RawPKS!
Value: 42
```

### 3. Hot Reload Development

```bash
# Terminal 1 - Start watching
rpks start

# Terminal 2 - Edit your file
# Make changes to .pks file
# Save it - Terminal 1 auto-reloads!
```

## Commands

### `rpks start`
Start real-time loader with hot-reload

Options:
- `-d, --directory` - Watch directory (default: `~/.packscript/scripts`)
- `-v, --verbose` - Show detailed output

```bash
rpks start                   # Default directory
rpks start -d ./scripts      # Custom directory
rpks start -v                # Verbose
```

### `rpks run <file>`
Execute a single script

```bash
rpks run mymod.pks
rpks run ./scripts/test.pks
rpks run -v mymod.pks        # Verbose
```

### `rpks load`
Load all scripts from watch directory

```bash
rpks load
rpks load -d ./scripts
```

### `rpks execute`
Load and execute all scripts

```bash
rpks execute
rpks execute -d ./scripts
```

### `rpks status`
Show runtime status

```bash
rpks status
```

Output:
```
RawPKS Runtime Status
------------------------------------------------------------
Running: False
Watch Directory: /home/user/.packscript/scripts
Loaded Scripts: 3
Variables: 5
Subscripts: 2
Triggers: 1

Scripts:
  - /home/user/.packscript/scripts/test.pks
  - /home/user/.packscript/scripts/utils.pks
  - /home/user/.packscript/scripts/main.pks
```

### `rpks vars`
List all variables

```bash
rpks vars
```

Output:
```
Variables:
  counter = 42
  name = "Test"
  enabled = true
```

## Examples

### Example 1: Basic Testing

Create `test.pks`:

```packscript
#init
modname(Test)
modver(1.0.0)
overridegamefiles(false)

#script

log.print("Test 1: Variables")
setvar(x, 10)
setvar(y, 20)
log.print(x)
log.print(y)

log.print("Test 2: Conditionals")
if(x < y) {
    log.print("X is less than Y")
}

log.print("Test 3: Loops")
for i = 1 to 4 {
    log.print(i)
}

log.print("All tests passed!")
```

Run:
```bash
rpks run test.pks
```

### Example 2: Development Workflow

1. Create `dev.pks`:
```packscript
#init
modname(Development)
modver(1.0.0)
overridegamefiles(false)

#script

setvar(result, 0)
for i = 1 to 10 {
    setvar(result, result + i)
}
log.print("Sum: ")
log.print(result)
```

2. Start watching:
```bash
rpks start -d . -v
```

3. Edit `dev.pks`, change the loop or calculation

4. Save - it auto-executes!

### Example 3: Using Packages

Create `with-packages.pks`:

```packscript
#init
modname(WithPackages)
modver(1.0.0)
packages(easylog)

preload(
    import from(easylog) get(log_info, log_error)
)

#script

log_info("This is informational")
log_error("This is an error message")
```

Run:
```bash
rpks run with-packages.pks
```

### Example 4: Multi-File Watch

Directory structure:
```
scripts/
├── main.pks
├── utils.pks
└── config.pks
```

Start watching:
```bash
rpks start -d ./scripts -v
```

All files auto-load and execute!

## Development Workflow

### VS Code Setup

1. Open your `.pks` file in VS Code
2. Split terminal (VS Code built-in)
3. Start `rpks start -v` in terminal
4. Edit file in editor
5. Save (Ctrl+S)
6. See output in terminal instantly

### Watch Multiple Projects

```bash
# Terminal 1
rpks start -d ./project1

# Terminal 2
rpks start -d ./project2

# Work on both simultaneously
```

### Debug Workflow

```bash
# Add debug output to your script
log.print("DEBUG: Starting process")
log.print("DEBUG: x = ")
log.print(x)

# Save and see it execute instantly
# No compile step needed!
```

## Features In Detail

### Hot Reload

When you save a file, RawPKS automatically:
1. Detects the change (file hash comparison)
2. Re-parses the file
3. Re-executes all statements
4. Shows any errors

All in real-time!

### File Watching

Watches for:
- New `.pks` files
- Modified `.pks` files
- Files in subdirectories

```
scripts/
├── main.pks              ✓ Watched
├── modules/
│   ├── logging.pks       ✓ Watched
│   └── debug.pks         ✓ Watched
└── archive/
    └── old.pks           ✓ Watched
```

### Variable State

Variables persist across execution:

```packscript
/* First run */
setvar(counter, 0)

/* Later execution */
setvar(counter, counter + 1)  /* counter = 1 */
```

### Error Handling

Errors are caught and reported:

```
[ERROR] Error: Syntax error in script
  Line 5: Unexpected token
  
Script continues watching
```

## Performance

- Lightweight directory monitoring (1 second interval)
- Efficient file change detection (SHA256 hashing)
- Fast parsing and execution
- Minimal memory overhead
- Single-threaded execution

## Limitations

### Runtime-Only
- Variables don't persist between runs
- No file I/O
- No network operations
- Single-threaded execution

### Development Tool
- Not for production use
- Local execution only
- Single user at a time

## Troubleshooting

### "Script not found"
Check file path and directory:
```bash
rpks status -d ./mydir
```

### "Variables disappearing"
Variables are runtime-only. Redefine in each script or session.

### "Hot reload not working"
Verify:
- File is saved properly
- Watch directory is correct
- File has `.pks` extension
- Try: `rpks -v start`

### "Port already in use"
Kill existing rpks process:
```bash
# Check running processes
ps aux | grep rpks

# Kill by PID
kill <PID>
```

## Integration with PackScript Ecosystem

### With Ducky

RawPKS works with Ducky packages:

```bash
ducky install easylog
rpks run mymod.pks  # Can use easylog
```

### With Compiler

Compile after developing:

```bash
# Develop with RawPKS
rpks run mymod.pks

# When satisfied, compile
pks mymod.pks

# Use mymod.java with Minecraft
```

## Advanced Usage

### Programmatic Usage

```python
from rpks_runtime.runtime import RPKSRuntime

runtime = RPKSRuntime("./scripts")
runtime.load_all_scripts()
runtime.execute_all_scripts()

variables = runtime.get_variables()
```

### Custom Watch Directory

```bash
# Development
rpks start -d ~/packscript/dev

# Testing
rpks start -d ~/packscript/tests

# Production scripts
rpks start -d ~/packscript/prod
```

## Best Practices

### 1. Use Descriptive Names
```packscript
setvar(player_health, 100)  # Good
setvar(ph, 100)             # Avoid
```

### 2. Test Before Compiling
```bash
# Test with RawPKS first
rpks run mymod.pks

# Then compile
pks mymod.pks
```

### 3. Organize Scripts
```
scripts/
├── core/
│   ├── player.pks
│   └── game.pks
├── utils/
│   ├── logging.pks
│   └── math.pks
└── experiments/
    └── feature-test.pks
```

### 4. Use Comments
```packscript
~ Development note: Testing health calculations
setvar(health, 20)
```

### 5. Start Simple
```packscript
~ Test basic functionality first
log.print("Testing...")

~ Add complexity gradually
```

## Examples Directory

Check `examples/` for more:
- `rawpks_demo.pks` - RawPKS demo script
- `hello_world.pks` - Basic example
- `player_events.pks` - Event handling
- `control_flow.pks` - Control flow

## Next Steps

1. **Install:** `ducky install rpks`
2. **Run:** `rpks run examples/hello_world.pks`
3. **Try:** Edit and save to see hot-reload
4. **Explore:** Create your own scripts
5. **Develop:** Use for rapid prototyping
6. **Compile:** When done, use `pks` compiler

---

RawPKS makes PackScript development fast, interactive, and productive! 🚀

For more help:
- Check examples in `examples/`
- Read the main README
- See LANGUAGE.md for syntax

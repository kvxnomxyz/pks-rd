"""
PackScript Package Creator - Creates .acpg (Advanced Compressed Package) files
Supports nested packages, dependencies, and flexible packaging options
"""
import os
import zipfile
import json
import sys
from pathlib import Path
from typing import Optional, Dict, List


def resolve_package_path(package_ref: str, base_dir: str = None) -> Optional[Path]:
    """
    Resolve a package reference to a directory path.
    
    Examples:
        "player" -> packages/player
        "packages/player" -> packages/player
        "./player" -> packages/player
        "/abs/path/player" -> /abs/path/player
    """
    if base_dir is None:
        base_dir = Path(__file__).parent
    
    base_dir = Path(base_dir)
    
    # Try as-is first (absolute or relative from cwd)
    pkg_path = Path(package_ref)
    if pkg_path.is_dir() and (pkg_path / "package.json").exists():
        return pkg_path
    
    # Try relative to packages directory
    pkg_path = base_dir / package_ref
    if pkg_path.is_dir() and (pkg_path / "package.json").exists():
        return pkg_path
    
    # Try removing 'packages/' prefix if present
    if package_ref.startswith("packages/"):
        pkg_path = base_dir / package_ref.replace("packages/", "")
        if pkg_path.is_dir() and (pkg_path / "package.json").exists():
            return pkg_path
    
    return None


def load_package_metadata(package_dir: Path) -> Dict:
    """Load and validate package.json"""
    package_json = package_dir / "package.json"
    
    if not package_json.exists():
        raise FileNotFoundError(f"package.json not found in {package_dir}")
    
    try:
        with open(package_json, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid package.json in {package_dir}: {e}")


def get_package_info(package_dir: Path) -> tuple:
    """Get package name and version from metadata"""
    metadata = load_package_metadata(package_dir)
    name = metadata.get("name", "unknown")
    version = metadata.get("version", "1.0.0")
    return name, version


def validate_package(package_dir: Path) -> tuple:
    """
    Validate package structure.
    Returns: (is_valid, error_message, metadata)
    """
    if not package_dir.is_dir():
        return False, f"Not a directory: {package_dir}", None
    
    package_json = package_dir / "package.json"
    if not package_json.exists():
        return False, f"Missing package.json in {package_dir}", None
    
    try:
        metadata = load_package_metadata(package_dir)
        
        # Validate required fields
        required = ["name", "version", "author", "description"]
        missing = [f for f in required if f not in metadata or not metadata[f]]
        
        if missing:
            return False, f"Missing required fields in package.json: {', '.join(missing)}", None
        
        return True, "Valid", metadata
    except Exception as e:
        return False, str(e), None


def include_dependency(zipf: zipfile.ZipFile, dep_name: str, packages_dir: Path, prefix: str = "deps"):
    """
    Include a dependency package inside another package.
    
    Creates structure like: deps/package-name/files...
    """
    dep_path = resolve_package_path(dep_name, packages_dir)
    
    if not dep_path:
        print(f"  ⚠ Warning: Dependency '{dep_name}' not found, skipping")
        return
    
    dep_name, dep_version = get_package_info(dep_path)
    dep_folder = f"{prefix}/{dep_name}-{dep_version}"
    
    print(f"  → Including {dep_name}@{dep_version}")
    
    for file_path in dep_path.rglob('*'):
        if file_path.is_file():
            arcname = f"{dep_folder}/{file_path.relative_to(dep_path)}"
            zipf.write(file_path, arcname)


def create_package(package_ref: str, output_path: str = None, include_deps: bool = False, 
                  packages_dir: str = None) -> str:
    """
    Create a .acpg file from a package directory.
    
    Args:
        package_ref: Package name or path (e.g., "player", "packages/player", "/abs/path")
        output_path: Output file path (defaults to dist/name-version.acpg)
        include_deps: Whether to bundle dependencies
        packages_dir: Base packages directory (for resolving relative paths)
    
    Returns:
        Path to created .acpg file
    """
    if packages_dir is None:
        packages_dir = Path(__file__).parent
    else:
        packages_dir = Path(packages_dir)
    
    # Resolve package path
    package_dir = resolve_package_path(package_ref, packages_dir)
    
    if not package_dir:
        raise FileNotFoundError(
            f"Package '{package_ref}' not found.\n"
            f"Tried:\n"
            f"  - {package_ref}\n"
            f"  - {packages_dir / package_ref}\n"
            f"  - {packages_dir / package_ref.lstrip('packages/')}\n"
            f"Make sure you're in the right directory or use full path."
        )
    
    # Validate package
    is_valid, error_msg, metadata = validate_package(package_dir)
    if not is_valid:
        raise ValueError(f"Invalid package: {error_msg}")
    
    pkg_name = metadata.get("name", "unknown")
    pkg_version = metadata.get("version", "1.0.0")
    
    # Determine output path
    if output_path is None:
        output_dir = packages_dir.parent / "dist"
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / f"{pkg_name}-{pkg_version}.acpg"
    else:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Create the zip file
    print(f"Creating package: {pkg_name}@{pkg_version}")
    
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Add all files from the package directory
        file_count = 0
        for file_path in package_dir.rglob('*'):
            if file_path.is_file():
                arcname = file_path.relative_to(package_dir)
                zipf.write(file_path, arcname)
                file_count += 1
        
        print(f"  ✓ Added {file_count} files")
        
        # Include dependencies if requested
        if include_deps and "dependencies" in metadata:
            deps = metadata.get("dependencies", [])
            if deps:
                print(f"  ✓ Including {len(deps)} dependencies:")
                for dep in deps:
                    include_dependency(zipf, dep, packages_dir)
    
    print(f"✓ Package created: {output_path}\n")
    return str(output_path)


def create_all_packages(packages_dir: str = None, include_deps: bool = False):
    """Create all packages in a directory"""
    
    if packages_dir is None:
        packages_dir = Path(__file__).parent
    else:
        packages_dir = Path(packages_dir)
    
    packages_dir = Path(packages_dir)
    
    created = []
    failed = []
    
    for pkg_dir in sorted(packages_dir.iterdir()):
        if pkg_dir.is_dir() and (pkg_dir / "package.json").exists():
            try:
                output_path = packages_dir.parent / "dist" / f"{pkg_dir.name}.acpg"
                result = create_package(
                    pkg_dir.name,
                    str(output_path),
                    include_deps=include_deps,
                    packages_dir=str(packages_dir)
                )
                created.append(pkg_dir.name)
            except Exception as e:
                failed.append((pkg_dir.name, str(e)))
                print(f"✗ Error creating package {pkg_dir.name}: {e}\n")
    
    print(f"\n{'='*50}")
    print(f"Created: {len(created)} packages")
    print(f"Failed: {len(failed)} packages")
    
    if created:
        print(f"\nSuccessful:")
        for name in created:
            print(f"  ✓ {name}")
    
    if failed:
        print(f"\nFailed:")
        for name, error in failed:
            print(f"  ✗ {name}: {error}")


def show_help():
    """Display help text"""
    print("""
PackScript Package Creator - .acpg (Advanced Compressed Package) tool

Usage:
  python packager.py [COMMAND] [OPTIONS]

Commands:
  packager.py                    # Create all packages in packages/
  packager.py <package>          # Create specific package (e.g., packager.py player)
  packager.py <path>             # Create from full/relative path
  packager.py --all              # Create all packages (same as no args)
  packager.py --all --deps       # Create all with dependencies bundled
  packager.py <pkg> --deps       # Create package with dependencies
  packager.py --validate <pkg>   # Validate package structure
  packager.py --list             # List available packages
  packager.py --help             # Show this help

Examples:
  python packager.py                     # Create all packages
  python packager.py player              # Create player package
  python packager.py packages/chat       # Full path reference
  python packager.py ./rpks              # Relative path
  python packager.py player --deps       # Include dependencies
  python packager.py --validate player   # Check structure
  python packager.py --list              # Show available packages

Package Structure:
  packages/
  ├── player/
  │   ├── package.json
  │   ├── player.pks
  │   └── README.md
  └── chat/
      ├── package.json
      └── chat.pks

package.json Requirements:
  {
    "name": "package-name",         (required)
    "version": "1.0.0",             (required)
    "author": "Your Name",          (required)
    "description": "What it does",  (required)
    "dependencies": []              (optional)
  }

Output:
  All packages created in: dist/
  Example: dist/player-1.1.0.acpg
    """)


if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] == "--all":
        # Create all packages
        include_deps = "--deps" in sys.argv
        create_all_packages(include_deps=include_deps)
    
    elif sys.argv[1] == "--help" or sys.argv[1] == "-h":
        show_help()
    
    elif sys.argv[1] == "--list":
        # List available packages
        packages_dir = Path(__file__).parent
        print("Available packages:\n")
        for pkg_dir in sorted(packages_dir.iterdir()):
            if pkg_dir.is_dir() and (pkg_dir / "package.json").exists():
                try:
                    name, version = get_package_info(pkg_dir)
                    print(f"  ✓ {name}@{version}")
                except:
                    print(f"  ✗ {pkg_dir.name} (invalid package.json)")
    
    elif sys.argv[1] == "--validate":
        if len(sys.argv) < 3:
            print("Error: --validate requires a package name")
            sys.exit(1)
        
        pkg_ref = sys.argv[2]
        is_valid, msg, metadata = validate_package(resolve_package_path(pkg_ref) or Path(pkg_ref))
        
        if is_valid:
            print(f"✓ Valid package: {metadata['name']}@{metadata['version']}")
            print(f"  Author: {metadata.get('author', 'N/A')}")
            print(f"  Description: {metadata.get('description', 'N/A')}")
            deps = metadata.get("dependencies", [])
            print(f"  Dependencies: {', '.join(deps) if deps else 'None'}")
        else:
            print(f"✗ Invalid: {msg}")
            sys.exit(1)
    
    else:
        # Create specific package
        package_ref = sys.argv[1]
        include_deps = "--deps" in sys.argv
        
        try:
            result = create_package(package_ref, include_deps=include_deps)
            print(f"Success! Package: {result}")
        except Exception as e:
            print(f"Error: {e}")
            print(f"\nTip: Run 'python packager.py --list' to see available packages")
            sys.exit(1)

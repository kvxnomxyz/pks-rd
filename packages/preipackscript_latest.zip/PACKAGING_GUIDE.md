# Packaging Packages: Nesting & Dependencies Guide

## Problem & Solution

**Before**: `python packager.py player` didn't work because paths weren't resolved correctly.

**Now**: The packager is smart about finding packages and can bundle dependencies!

## Quick Start

### Create a Single Package

```bash
# By name (auto-resolves from packages/)
python packager.py player

# By full path
python packager.py packages/player

# By relative path
python packager.py ./chat

# All three work! ✓
```

### Create All Packages

```bash
# Simple
python packager.py

# With bundled dependencies
python packager.py --all --deps
```

## How to Use Dependencies

### 1. Define Dependencies in package.json

```json
{
  "name": "chat",
  "version": "1.2.0",
  "author": "PackScript Team",
  "description": "Chat system for messages",
  "dependencies": ["easylog"],
  "files": ["chat.pks"]
}
```

### 2. Create Package With Dependencies Bundled

```bash
# Include dependencies inside the package
python packager.py chat --deps
```

### 3. Result: Nested Package Structure

```
chat-1.2.0.acpg
├── package.json
├── chat.pks
└── deps/
    └── easylog-1.0.0/
        ├── package.json
        ├── easylog.pks
        └── README.md
```

## Packaging Architecture

### Simple Package (No Dependencies)

```
player-1.1.0.acpg
├── package.json          ← Metadata
├── player.pks            ← Source code
└── README.md            ← Documentation
```

### Complex Package (With Dependencies)

```
chat-1.2.0.acpg
├── package.json          ← Chat metadata
├── chat.pks              ← Chat source
├── README.md             ← Chat docs
└── deps/                 ← Nested dependencies
    └── easylog-1.0.0/
        ├── package.json
        ├── easylog.pks
        └── README.md
```

### Multi-Level Dependencies

```
advanced-app-2.0.0.acpg
├── package.json
├── app.pks
├── deps/
│   ├── chat-1.2.0/
│   │   ├── package.json
│   │   ├── chat.pks
│   │   └── deps/
│   │       └── easylog-1.0.0/
│   │           └── ... (bundled)
│   └── player-1.1.0/
│       ├── package.json
│       └── player.pks
```

## All Packager Commands

### Basic Commands

```bash
# Create all packages
python packager.py
python packager.py --all

# Create specific package
python packager.py player
python packager.py packages/chat
python packager.py ./rpks

# Create with dependencies bundled
python packager.py player --deps
python packager.py --all --deps
```

### Information Commands

```bash
# List available packages
python packager.py --list

# Validate package structure
python packager.py --validate player
python packager.py --validate chat

# Show help
python packager.py --help
python packager.py -h
```

### Output

All packages created in: `dist/`

Examples:
```
dist/player-1.1.0.acpg
dist/chat-1.2.0.acpg
dist/easylog-1.0.0.acpg
```

## Creating Your Own Package

### Step 1: Create Package Directory

```bash
mkdir packages/mypackage
cd packages/mypackage
```

### Step 2: Create package.json

```json
{
  "name": "mypackage",
  "version": "1.0.0",
  "author": "Your Name",
  "description": "What this package does",
  "dependencies": ["easylog"],
  "files": ["*.pks", "README.md"]
}
```

### Step 3: Add PackScript Code

Create `mypackage.pks`:
```packscript
subscript.define(
    name(my_function)
    parameters(player)
    script(
        log.print("Hello from mypackage!")
    )
)
```

### Step 4: Create README.md

```markdown
# MyPackage

Description of what it does.

## Usage

```packscript
preload(
    import from(mypackage) get(my_function)
)

#script
run(my_function("player1"))
```

## Installation

```bash
ducky install mypackage
```
```

### Step 5: Package It

```bash
# Without dependencies
python packager.py mypackage

# With dependencies bundled
python packager.py mypackage --deps
```

Result: `dist/mypackage-1.0.0.acpg`

## Dependency Management

### What Are Dependencies?

Dependencies are other packages that your package uses:

```json
{
  "dependencies": ["easylog", "logging-utils"]
}
```

### Types of Packaging

#### 1. Minimal Package (No Dependencies)
```bash
python packager.py player
```
- Smaller file size
- Requires dependencies installed separately
- Use for: Simple utilities

#### 2. Bundled Package (With Dependencies)
```bash
python packager.py chat --deps
```
- Larger file size but self-contained
- Includes all dependencies
- Use for: Complex applications, distribution

#### 3. Minimal with External Dependencies
```bash
# Create package
python packager.py chat

# Ducky handles dependencies during installation
ducky install chat
# Ducky automatically installs easylog too
```

## Nested Dependency Examples

### Example 1: Simple Chain

User installs `chat`:
```
ducky install chat
```

Ducky automatically installs:
```
chat (depends on easylog)
└── easylog
```

### Example 2: Bundled Chain

Create bundled package:
```bash
python packager.py chat --deps
```

Package contains:
```
chat-1.2.0.acpg
├── chat.pks
└── deps/
    └── easylog-1.0.0/
        └── easylog.pks
```

Installation:
```bash
ducky install chat-bundled
```

Everything included, no extra downloads!

### Example 3: Complex Application

```
advanced-app-2.0.0.acpg
├── app.pks (main app)
├── deps/
│   ├── chat-1.2.0-bundled/
│   │   ├── chat.pks
│   │   └── deps/
│   │       └── easylog-1.0.0/
│   └── player-1.1.0/
│       └── player.pks
```

## Path Resolution Examples

The packager is smart about finding packages:

```bash
# All of these work identically:
python packager.py player
python packager.py packages/player
python packager.py ./packages/player
python packager.py c:\full\path\to\packages\player
```

### Resolution Order

1. Try exact path as-is
2. Try relative to packages/ directory
3. Try removing "packages/" prefix
4. Return error with suggestions

## Validation & Debugging

### Validate Package Structure

```bash
python packager.py --validate chat

Output:
✓ Valid package: chat@1.2.0
  Author: PackScript Team
  Description: Chat system for managing...
  Dependencies: easylog
```

### List All Packages

```bash
python packager.py --list

Output:
Available packages:

  ✓ chat@1.2.0
  ✓ easylog@1.0.0
  ✓ player@1.1.0
  ✓ rpks@1.0.0
```

### Check File Contents

```bash
# List files in package
unzip -l dist/player-1.1.0.acpg

# Extract and inspect
unzip dist/player-1.1.0.acpg -d temp/
cat temp/package.json
```

## Best Practices

### 1. Organize Dependencies

**Good**:
```json
{
  "dependencies": ["logging", "utilities"]
}
```

**Avoid circular dependencies**:
```json
{
  "dependencies": ["a", "b"]
}
// And a depends on this package -> CIRCULAR!
```

### 2. Use Bundling Strategically

**Bundle when**:
- Creating a complete application
- Distributing across unreliable networks
- Ensuring exact versions

**Don't bundle when**:
- Many shared dependencies
- Large packages (file size matters)
- Frequent updates

### 3. Version Your Packages

```json
{
  "version": "1.0.0"  // MAJOR.MINOR.PATCH
}
```

Increment:
- MAJOR for breaking changes
- MINOR for new features
- PATCH for bug fixes

### 4. Document Dependencies

```markdown
## Dependencies

- **easylog**: For logging functionality
- **player-utils**: For player management

## Optional Requirements

- Minecraft Forge 1.19+
- Java 11+
```

### 5. Test Before Packaging

```bash
# Validate
python packager.py --validate mypackage

# Create
python packager.py mypackage

# Test install
ducky install dist/mypackage-1.0.0.acpg

# Use it
ducky show mypackage
```

## Troubleshooting

### "Package not found" Error

**Problem**: `FileNotFoundError: Package 'xyz' not found`

**Solution**:
```bash
# List available packages
python packager.py --list

# Check directory exists
ls packages/

# Check package.json exists
ls packages/xyz/package.json
```

### "Invalid package.json" Error

**Problem**: `ValueError: Invalid package: Missing required fields...`

**Solution**: Verify package.json has all required fields:
```json
{
  "name": "...",          // Required
  "version": "...",       // Required
  "author": "...",        // Required
  "description": "...",   // Required
  "dependencies": []      // Optional but recommended
}
```

### Dependency Not Bundled

**Problem**: Files don't appear in deps/ folder

**Check**:
```bash
# Add --deps flag!
python packager.py mypackage --deps

# Verify dependency exists
python packager.py --list
```

### Path Resolution Issues

**All of these work**:
```bash
python packager.py player              # Name only
python packager.py packages/player     # Full relative
python packager.py ./packages/player   # Explicit relative
python packager.py /abs/path/player    # Absolute
```

## Advanced Usage

### Custom Output Path

```bash
# API usage (in Python script)
from packager import create_package

create_package(
    package_ref="player",
    output_path="/custom/path/my-player.acpg"
)
```

### Conditional Bundling

```bash
# Create script that conditionally bundles
import sys
from pathlib import Path

if "--production" in sys.argv:
    # Bundle for production
    os.system("python packager.py --all --deps")
else:
    # Minimal for development
    os.system("python packager.py --all")
```

### Automation Script

```bash
#!/bin/bash
# build-packages.sh

echo "Validating packages..."
python packager.py --validate chat
python packager.py --validate player

echo "Creating packages..."
python packager.py --all --deps

echo "Verifying distribution..."
ls -lh dist/*.acpg

echo "Done!"
```

---

## Summary

**The enhanced packager.py now provides:**

✅ Smart path resolution (names, relative, absolute paths)
✅ Dependency bundling (`--deps` flag)
✅ Package validation (`--validate`)
✅ Package listing (`--list`)
✅ Better error messages
✅ Professional help documentation
✅ Nested package support

**Quick commands**:
```bash
python packager.py                    # Create all
python packager.py player             # Create one
python packager.py --all --deps       # Create all with deps
python packager.py --list             # List packages
python packager.py --validate player  # Validate
python packager.py --help             # Show help
```

No more path errors! 🎉

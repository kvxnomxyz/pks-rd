#!/usr/bin/env pwsh
<#
.SYNOPSIS
    PackScript All-in-One Installer
    Downloads and installs PackScript and Ducky package manager

.DESCRIPTION
    This script:
    1. Downloads clean PackScript distribution
    2. Checks/installs Python if needed
    3. Extracts PackScript
    4. Runs the AiO installer to download Ducky
    5. Sets up environment variables

.PARAMETER SkipPython
    Skip Python download/install (assumes Python already installed)

.PARAMETER SkipDucky
    Skip Ducky installation (only install PackScript)

.PARAMETER Verbose
    Enable verbose output during installation

.EXAMPLE
    .\install.ps1
    .\install.ps1 -SkipPython
    .\install.ps1 -Verbose
#>

param(
    [switch]$SkipPython,
    [switch]$SkipDucky,
    [switch]$Verbose
)

# Colors
$colors = @{
    Error = 'Red'
    Warning = 'Yellow'
    Success = 'Green'
    Info = 'Cyan'
    Neutral = 'White'
}

function Write-Log {
    param(
        [string]$Message,
        [string]$Level = 'Info'
    )
    
    $color = $colors[$Level]
    if (-not $color) { $color = $colors['Neutral'] }
    
    $timestamp = Get-Date -Format "HH:mm:ss"
    Write-Host "[$timestamp] " -NoNewLine -ForegroundColor Gray
    Write-Host $Message -ForegroundColor $color
}

function Test-AdminRights {
    $isAdmin = [bool]([System.Security.Principal.WindowsIdentity]::GetCurrent().Groups -match 'S-1-5-32-544')
    return $isAdmin
}

function Test-Python {
    try {
        $python = python --version 2>&1
        Write-Log "✓ Python found: $python" 'Success'
        return $true
    }
    catch {
        Write-Log "Python not found" 'Warning'
        return $false
    }
}

function Install-Python {
    Write-Log "Downloading Python installer..." 'Info'
    
    $pythonInstaller = "$env:TEMP\python-installer.exe"
    $pythonURL = "https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe"
    
    try {
        # Download Python installer
        Write-Log "Fetching from: $pythonURL" 'Neutral'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $pythonURL -OutFile $pythonInstaller -ErrorAction Stop
        Write-Log "✓ Python installer downloaded" 'Success'
        
        # Install Python
        Write-Log "Installing Python (can take 2-3 minutes)..." 'Info'
        & $pythonInstaller /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
        
        # Wait for installation to complete
        Start-Sleep -Seconds 5
        
        # Verify installation
        if (Test-Python) {
            Write-Log "✓ Python installed successfully" 'Success'
            return $true
        } else {
            Write-Log "Python installation verification failed" 'Error'
            return $false
        }
    }
    catch {
        Write-Log "Failed to install Python: $_" 'Error'
        return $false
    }
    finally {
        if (Test-Path $pythonInstaller) {
            Remove-Item $pythonInstaller -Force
        }
    }
}

function Download-PackScript {
    param(
        [string]$DownloadPath
    )
    
    Write-Log "Downloading PackScript distribution..." 'Info'
    
    $url = "https://raw.githubusercontent.com/kvxnomxyz/pks-rd/packages/preipackscript_latest.zip"
    
    try {
        Write-Log "Source: $url" 'Neutral'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        
        Invoke-WebRequest -Uri $url -OutFile $DownloadPath -ErrorAction Stop
        Write-Log "✓ PackScript downloaded: $(Get-Item $DownloadPath | Select-Object -ExpandProperty Length | ForEach-Object {$_/1MB} )MB" 'Success'
        return $true
    }
    catch {
        Write-Log "Failed to download PackScript: $_" 'Error'
        return $false
    }
}

function Extract-PackScript {
    param(
        [string]$ZipPath,
        [string]$ExtractPath
    )
    
    Write-Log "Extracting PackScript..." 'Info'
    
    try {
        New-Item -ItemType Directory -Path $ExtractPath -Force | Out-Null
        Expand-Archive -Path $ZipPath -DestinationPath $ExtractPath -Force -ErrorAction Stop
        Write-Log "✓ Extracted to: $ExtractPath" 'Success'
        return $true
    }
    catch {
        Write-Log "Failed to extract: $_" 'Error'
        return $false
    }
}

function Run-Installer {
    param(
        [string]$PackScriptPath
    )
    
    Write-Log "Running PackScript All-in-One Installer..." 'Info'
    
    $installerScript = Join-Path $PackScriptPath "installer\aio_installer.py"
    
    if (-not (Test-Path $installerScript)) {
        Write-Log "Installer not found at: $installerScript" 'Error'
        return $false
    }
    
    try {
        & python $installerScript --cli
        Write-Log "✓ Installer completed" 'Success'
        return $true
    }
    catch {
        Write-Log "Installer failed: $_" 'Error'
        return $false
    }
}

function Set-EnvironmentPath {
    Write-Log "Verifying environment setup..." 'Info'
    
    $duckyHome = Join-Path $env:USERPROFILE ".ducky"
    
    if (-not (Test-Path $duckyHome)) {
        Write-Log "Warning: DUCKY_HOME not found at $duckyHome" 'Warning'
        return $false
    }
    
    Write-Log "✓ DUCKY_HOME: $duckyHome" 'Success'
    return $true
}

# Main installation flow
Write-Host "`n" + ("="*60) -ForegroundColor Cyan
Write-Host "  PackScript & Ducky All-in-One Installer" -ForegroundColor Cyan
Write-Host ("="*60) -ForegroundColor Cyan
Write-Host ""

# Step 1: Check Python
Write-Log "Step 1: Checking Python Installation" 'Info'
Write-Host ""

if ($SkipPython) {
    Write-Log "Skipping Python check (--SkipPython)" 'Warning'
} else {
    if (-not (Test-Python)) {
        if (-not (Test-AdminRights)) {
            Write-Log "Admin rights required to install Python" 'Error'
            Write-Log "Solution: Run this script as Administrator" 'Info'
            exit 1
        }
        
        if (-not (Install-Python)) {
            Write-Log "Could not install Python" 'Error'
            exit 1
        }
    }
}

Write-Host ""

# Step 2: Download PackScript
Write-Log "Step 2: Downloading PackScript" 'Info'
Write-Host ""

$tempDir = Join-Path $env:TEMP "packscript-install"
$zipFile = Join-Path $tempDir "preipackscript.zip"

New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

if (-not (Download-PackScript -DownloadPath $zipFile)) {
    Write-Log "Installation failed" 'Error'
    exit 1
}

Write-Host ""

# Step 3: Extract PackScript
Write-Log "Step 3: Extracting PackScript" 'Info'
Write-Host ""

$installPath = Join-Path $env:USERPROFILE "PackScript"

if (-not (Extract-PackScript -ZipPath $zipFile -ExtractPath $installPath)) {
    Write-Log "Installation failed" 'Error'
    exit 1
}

Write-Host ""

# Step 4: Run AiO Installer
Write-Log "Step 4: Running PackScript Installer" 'Info'
Write-Host ""

if (-not (Run-Installer -PackScriptPath $installPath)) {
    Write-Log "Installation failed" 'Error'
    exit 1
}

Write-Host ""

# Step 5: Verify Setup
Write-Log "Step 5: Verifying Installation" 'Info'
Write-Host ""

Set-EnvironmentPath | Out-Null

Write-Host ""
Write-Host ("="*60) -ForegroundColor Green
Write-Host "  ✓ INSTALLATION COMPLETE!" -ForegroundColor Green
Write-Host ("="*60) -ForegroundColor Green
Write-Host ""

Write-Log "Installation Summary:" 'Success'
Write-Host "  • PackScript: $installPath" -ForegroundColor White
Write-Host "  • Ducky Home: $env:USERPROFILE\.ducky" -ForegroundColor White
Write-Host ""

Write-Log "Next Steps:" 'Info'
Write-Host "  1. Close and reopen PowerShell" -ForegroundColor Cyan
Write-Host "  2. Verify installation: ducky list" -ForegroundColor Cyan
Write-Host "  3. Try first script: pks examples/hello_world.pks" -ForegroundColor Cyan
Write-Host ""

Write-Log "Documentation:" 'Neutral'
Write-Host "  • Language Guide: $installPath\LANGUAGE.md" -ForegroundColor Gray
Write-Host "  • Package Manager: $installPath\DUCKY.md" -ForegroundColor Gray
Write-Host "  • Quick Reference: $installPath\QUICKREF.md" -ForegroundColor Gray
Write-Host ""

# Cleanup
Write-Log "Cleaning up temporary files..." 'Neutral'
Remove-Item -Path $zipFile -Force -ErrorAction SilentlyContinue
Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ""

#init
modname(HelloWorld)
modver(1.0.0)
overridegamefiles(false)
packages()

#script

log.print("Hello PackScript!")
log.print("This is a simple example")

~ Set a variable
setvar(message, "Welcome to Minecraft")
log.print(message)

~ Get a variable
getvar(message)

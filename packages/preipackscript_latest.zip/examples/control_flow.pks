#init
modname(GameLogic)
modver(1.0.0)
overridegamefiles(false)
packages()

subscript.define(
    name(check_level)
    parameters(level)
    script(
        if(level >= 10) {
            log.print("High level!")
        } else {
            log.print("Low level")
        }
    )
)

subscript.define(
    name(count_loop)
    script(
        for i = 1 to 5 {
            log.print(i)
        }
    )
)

subscript.define(
    name(while_test)
    script(
        setvar(count, 0)
        while(count < 3) {
            log.print(count)
            setvar(count, count + 1)
        }
    )
)

trigger.add(
    name(level_check)
    subscript(check_level)
)

#script

log.print("Control flow examples")
run(trigger(level_check))

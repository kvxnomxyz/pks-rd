#init
modname(PlayerLogger)
modver(1.0.0)
overridegamefiles(false)
packages(easylog)

preload(
    import from(easylog) get(log_info, log_error)
)

subscript.define(
    name(on_player_join)
    parameters(player)
    script(
        log_info(player)
    )
)

subscript.define(
    name(on_player_quit)
    parameters(player)
    script(
        log_error(player)
    )
)

trigger.add(
    name(player_join)
    subscript(on_player_join)
)

trigger.add(
    name(player_quit)
    subscript(on_player_quit)
)

#script

log.print("Player tracking enabled")

~ Run the player join trigger
run(trigger(player_join))

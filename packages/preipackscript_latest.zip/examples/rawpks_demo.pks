~ Example of using RawPKS with hot-reload
~ Save this file and modify it - it will auto-reload!

#init
modname(RawPKSTest)
modver(1.0.0)
overridegamefiles(false)
packages()

#script

log.print("=" * 50)
log.print("RawPKS Real-Time Loader Example")
log.print("=" * 50)

~ Set some variables
setvar(counter, 0)
setvar(name, "TestScript")

~ Basic operations
log.print("Script Name: ")
log.print(name)

~ Loop example
log.print("Counting:")
for i = 1 to 6 {
    log.print("  Count: ")
    log.print(i)
    setvar(counter, counter + 1)
}

~ Conditional logic
if(counter > 5) {
    log.print("Counter exceeded 5!")
}

log.print("Total iterations: ")
log.print(counter)

log.print("=" * 50)
log.print("Script completed!")
log.print("Try editing this file and saving - it auto-reloads!")
log.print("=" * 50)

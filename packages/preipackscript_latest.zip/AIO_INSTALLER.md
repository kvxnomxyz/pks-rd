# All-in-One Installer (AiO) Guide

The **All-in-One Installer** is a hybrid CLI/GUI installation tool that sets up the complete PackScript ecosystem with a single command.

## Overview

The AiO installer automates:
- ✅ System requirement verification
- ✅ Ducky package manager download & extraction
- ✅ Environment variable configuration
- ✅ PATH setup (Windows registry or shell profiles)
- ✅ Repository index download
- ✅ Cross-platform compatibility (Windows, Linux, macOS)

## Installation

### Quick Start (Recommended)

**GUI Mode** (Visual interface):
```bash
python installer/aio_installer.py --gui
```

**CLI Mode** (Terminal interface):
```bash
python installer/aio_installer.py --cli
```

**Verbose Mode** (Detailed output):
```bash
python installer/aio_installer.py --gui --verbose
python installer/aio_installer.py --cli --verbose
```

### From Source

```bash
# Clone repository
git clone https://github.com/kvxnomxyz/pks-rd
cd packscript

# Run installer
python installer/aio_installer.py
```

## GUI Mode

### Features

- **Visual Progress Display**: See each installation step
- **Real-time Logging**: Watch operations as they happen
- **Progress Bar**: Visual indication of overall progress
- **Easy Navigation**: Simple buttons for control
- **Error Reporting**: Clear error messages with details
- **Graceful Fallback**: Automatically switches to CLI if GUI unavailable

### Interface

```
┌─────────────────────────────────────┐
│   PackScript Installer              │
│  All-in-One Package Installation    │
├─────────────────────────────────────┤
│ Installation Progress:              │
│                                     │
│ [Installation Output Window]        │
│ [20+ lines of detailed output]      │
│ [Auto-scrolling to latest message]  │
│                                     │
│ [Progress Bar]                      │
│                                     │
│ [Install] [Close]                   │
└─────────────────────────────────────┘
```

### GUI Workflow

1. **Launch**: `python installer/aio_installer.py --gui`
2. **Review Info**: Read the welcome screen
3. **Click Install**: Start the installation process
4. **Watch Progress**: See real-time status updates
5. **Success/Error**: Get clear feedback on completion
6. **Close**: Exit installer

## CLI Mode

### Features

- **Terminal-based**: Works over SSH and remote connections
- **Detailed Logging**: Full step-by-step output
- **Exit Codes**: Proper error reporting (0 = success, 1 = failure)
- **Script Friendly**: Easy integration with automation

### CLI Workflow

```bash
$ python installer/aio_installer.py --cli

============================================================
  PackScript All-in-One Installer (CLI Mode)
============================================================

[INFO] Checking installation requirements...
[INFO] ✓ Python 3.8.0
[INFO] ✓ OS: Windows
[INFO] ✓ Write permissions OK

==================================================
Step: Download Ducky
==================================================

[INFO] Downloading Ducky package manager...
[INFO] Fetching from: https://raw.githubusercontent.com/...
[INFO]   Downloaded: 25%
[INFO]   Downloaded: 50%
[INFO]   Downloaded: 75%
[INFO]   Downloaded: 100%
[INFO] ✓ Ducky downloaded successfully

==================================================
Step: Setup Environment
==================================================

[INFO] Setting up environment...
[INFO] Configuring Windows environment...
[INFO] ✓ Environment variables set
[INFO] ✓ Please restart your terminal

==================================================
✓ INSTALLATION COMPLETE!
==================================================

Next steps:
1. Restart your terminal
2. Run: ducky list
3. Start using PackScript!

Installation successful!
```

### CLI Options

```bash
python installer/aio_installer.py --help

optional arguments:
  -h, --help     show this help message and exit
  --cli          Use command-line interface
  --gui          Use graphical interface (default if available)
  -v, --verbose  Verbose output
```

## Installation Steps

### 1. Verify Requirements

The installer checks:

```python
✓ Python version >= 3.8
✓ Supported operating system (Windows, Linux, macOS)
✓ Write permissions in home directory
```

### 2. Download Ducky

```
Source: https://raw.githubusercontent.com/kvxnomxyz/pks-rd/packages/ducky.zip.acpg
Location: ~/.packscript/cache/ducky.zip.acpg
```

### 3. Extract Files

```
From: ducky.zip.acpg
To: ~/.ducky/
Contents:
  - Package manager
  - CLI tools
  - Configuration files
```

### 4. Setup Environment

**Windows**:
- Sets registry keys via `setx`
- Environment variables:
  - `DUCKY_HOME` = `C:\Users\Username\.ducky`
  - `PACKSCRIPT_HOME` = `C:\Users\Username\.packscript`

**Linux/macOS**:
- Updates shell profile:
  - `~/.zshrc` (zsh)
  - `~/.bash_profile` (bash login shell)
  - `~/.bashrc` (bash non-login shell)
- Export: `export DUCKY_HOME="$HOME/.ducky"`

### 5. Download Repository

```
Fetches: package-repositories.json
Source: https://raw.githubusercontent.com/kvxnomxyz/pks-rd/package-repositories.json
Packages: 4 (rpks, easylog, chat, player)
```

## Installation Locations

### Directory Structure

**Windows**:
```
C:\Users\Username\
├── .ducky/              # Ducky installation
│   ├── bin/             # Executable scripts
│   ├── packages/        # Installed packages
│   └── cache/           # Package cache
├── .packscript/         # PackScript data
│   ├── cache/           # Downloaded files
│   └── compiled/        # Compiled scripts
```

**Linux/macOS**:
```
~
├── .ducky/              # Ducky installation
│   ├── bin/
│   ├── packages/
│   └── cache/
└── .packscript/         # PackScript data
    ├── cache/
    └── compiled/
```

## After Installation

### Step 1: Restart Terminal

Close and reopen your terminal window to load new environment variables.

### Step 2: Verify Installation

```bash
# Check Ducky installation
ducky list

# Expected output:
# No packages installed
```

### Step 3: Install Packages

```bash
# Install real-time loader
ducky install rpks

# Install logging library
ducky install easylog

# Install chat system
ducky install chat

# Install player system
ducky install player
```

### Step 4: Test Compiler

```bash
# Create test file
echo 'log.print("Hello, PackScript!")' > test.pks

# Compile it
pks test.pks

# Output: test.java
```

## Troubleshooting

### GUI Won't Start

**Symptom**: "ModuleNotFoundError: No module named 'tkinter'"

**Solution**:
```bash
# Install tkinter
# Windows: Usually included with Python
# Linux (Ubuntu/Debian)
sudo apt-get install python3-tk

# Linux (Fedora)
sudo dnf install python3-tkinter

# macOS
brew install python-tk@3.11
```

**Fallback**:
```bash
python installer/aio_installer.py --cli
```

### Installation Fails at Download

**Symptom**: "URLError: [Errno -2] Name or service not known"

**Solution**:
- Check internet connection
- Verify firewall settings
- Check GitHub accessibility
- Try again later

### Environment Variables Not Set (Windows)

**Symptom**: "ducky: command not found"

**Solution**:
```bash
# Restart terminal completely
# Close and reopen PowerShell/CMD

# Manually verify
echo %DUCKY_HOME%

# If empty, set manually:
setx DUCKY_HOME "C:\Users\YourUsername\.ducky"
setx PACKSCRIPT_HOME "C:\Users\YourUsername\.packscript"
```

### Installation Fails Due to Permissions

**Symptom**: "PermissionError: [Errno 13] Permission denied"

**Solution**:
- Run installer with admin privileges:
  - **Windows**: Right-click PowerShell → "Run as administrator"
  - **Linux/macOS**: `sudo python installer/aio_installer.py --cli`
- Or change home directory permissions:
  - `chmod 755 ~` (Linux/macOS)

### PATH Not Updated (Linux/macOS)

**Symptom**: "ducky: command not found"

**Solution**:
```bash
# Source profile manually
source ~/.zshrc          # zsh
source ~/.bash_profile   # bash

# Or restart terminal completely
exit  # Close current shell
# Re-open terminal
```

## Advanced Options

### Silent Installation (No Output)

```bash
python installer/aio_installer.py --cli > /dev/null 2>&1
echo $?  # Check exit code (0 = success)
```

### Custom Installer Paths

Edit `aio_installer.py`:
```python
DUCKY_DOWNLOAD_URL = "https://your-custom-repo/ducky.zip.acpg"
REPO_INDEX_URL = "https://your-custom-repo/package-repositories.json"
```

### Integration with Scripts

```bash
#!/bin/bash
python installer/aio_installer.py --cli
if [ $? -eq 0 ]; then
    echo "Installation successful!"
    ducky list
else
    echo "Installation failed!"
    exit 1
fi
```

### Docker Installation

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY . .

RUN python installer/aio_installer.py --cli

ENTRYPOINT ["ducky"]
CMD ["list"]
```

## Platform-Specific Notes

### Windows

- Uses registry (`setx`) for environment variables
- Requires terminal restart for changes to take effect
- GUI requires `tkinter` (usually included)
- Supports PowerShell, Command Prompt, Windows Terminal

### Linux

- Supports bash and zsh shells
- GUI requires `python3-tk` package
- Updates shell profile automatically
- Works on Ubuntu, Fedora, Arch, Debian, etc.

### macOS

- Updates `.zshrc` (default since macOS 10.15)
- Also updates `.bash_profile` if present
- GUI requires tkinter (use Homebrew)
- Works on Intel and Apple Silicon

## Performance

### Installation Time

- **Typical**: 10-30 seconds
  - Download: 5-15 seconds (network dependent)
  - Extraction: 2-5 seconds
  - Environment: 3-10 seconds

- **Slow Connection** (< 1 Mbps): 1-3 minutes

### Disk Space Required

- **Minimum**: 50 MB
  - Ducky: 5-10 MB
  - Python libs: 30-40 MB

- **With Packages**: 100+ MB
  - Each package: 500 KB - 2 MB
  - Cache: 20-50 MB

## Uninstallation

### Windows

```bash
# Remove environment variables
setx DUCKY_HOME ""

# Remove directories
rmdir /s %USERPROFILE%\.ducky
rmdir /s %USERPROFILE%\.packscript
```

### Linux/macOS

```bash
# Remove from shell profile
nano ~/.zshrc  # Or ~/.bash_profile

# Remove the following lines:
# export DUCKY_HOME="$HOME/.ducky"

# Remove directories
rm -rf ~/.ducky
rm -rf ~/.packscript
```

## Support

### Getting Help

```bash
# Verbose output for debugging
python installer/aio_installer.py --cli --verbose

# Save output to file
python installer/aio_installer.py --cli --verbose > install.log 2>&1

# Check system info
python --version
python -m pip list
```

### Report Issues

Include:
1. Operating system and version
2. Python version
3. Installation log output
4. Error messages
5. Network setup (internet connection, proxies, firewall)

---

**Last Updated**: April 2026
**Installer Version**: 1.0
**Supported Python**: 3.8+
**Supported Platforms**: Windows 7+, Linux, macOS 10.14+

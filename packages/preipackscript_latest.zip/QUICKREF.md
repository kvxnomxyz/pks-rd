# PackScript Quick Reference

## Installation

```bash
python installer/install.py
```

Then restart your terminal.

## Compile a PackScript File

```bash
pks mymod.pks
```

Output: `mymod.java`

## Package Management

```bash
ducky install easylog        # Install a package
ducky list                   # List installed packages
ducky uninstall easylog      # Remove a package
ducky search logging         # Search for packages
ducky show easylog           # Package info
ducky info                   # Repository info
```

## Simple PackScript Program

```packscript
#init
modname(MyMod)
modver(1.0.0)
overridegamefiles(false)

#script

log.print("Hello from PackScript!")
setvar(x, 42)
getvar(x)

if(x > 40) {
    log.print("X is greater than 40")
}
```

## Using Functions

```packscript
subscript.define(
    name(greet)
    parameters(name)
    script(
        log.print("Hello, ")
        log.print(name)
    )
)

trigger.add(
    name(greeting)
    subscript(greet)
)

#script
run(trigger(greeting))
```

## Using Packages

```packscript
#init
modname(MyMod)
modver(1.0.0)
packages(easylog)

preload(
    import from(easylog) get(log_info, log_error)
)

#script

log_info("This is info")
log_error("This is an error")
```

## Control Flow

```packscript
~ If/else
if(condition) {
    ~ do something
} else {
    ~ do something else
}

~ For loop
for i = 1 to 10 {
    log.print(i)
}

~ While loop
while(count < 5) {
    log.print(count)
    setvar(count, count + 1)
}
```

## Operators

```packscript
~ Arithmetic
10 + 5  ~ 15
10 - 5  ~ 5
10 * 5  ~ 50
10 / 5  ~ 2

~ Comparison
x == 5
x != 5
x > 5
x < 5
x >= 5
x <= 5

~ Logical
true && false   ~ false
true || false   ~ true
!true           ~ false
```

## Built-in Functions

```packscript
log.print(message)          ~ Print to console
setvar(name, value)         ~ Set variable
getvar(name)                ~ Get variable
chatlog(player)             ~ Log chat
gamelog(message)            ~ Log event
```

## Comments

```packscript
~ This is a comment
setvar(x, 1)  ~ Inline comment
```

## Examples

See the `examples/` folder for complete examples:
- `hello_world.pks` - Basic example
- `player_events.pks` - Events and imports
- `control_flow.pks` - Loops and conditions

## File Locations

- Language: `packscript/compiler/`
- Package Manager: `ducky/`
- Examples: `examples/`
- Packages: `packages/`, `dist/`
- Documentation: `*.md` files

## Troubleshooting

### "pks command not found"
Restart your terminal or IDE

### "ducky command not found"
Restart your terminal or IDE

### "Module not found" error
Run: `python setup.py install`

## More Information

- **README.md** - Full documentation
- **LANGUAGE.md** - Complete language reference
- **DUCKY.md** - Package manager guide
- **INSTALL.md** - Installation help
- **PROJECT_SUMMARY.md** - Project overview

---

Happy modding! 🚀

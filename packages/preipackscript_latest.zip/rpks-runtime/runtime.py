"""
RawPKS (rpks) Runtime Loader
Loads and executes raw .pks files in real-time without pre-compilation
"""
import os
import sys
import time
import hashlib
import threading
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import traceback

from packscript.compiler.lexer import Lexer
from packscript.compiler.parser import Parser


class RPKSRuntime:
    """Runtime environment for executing PackScript files"""
    
    def __init__(self, watch_dir: str = None, verbose: bool = False):
        self.watch_dir = Path(watch_dir) if watch_dir else Path.home() / ".packscript" / "scripts"
        self.watch_dir.mkdir(parents=True, exist_ok=True)
        
        self.verbose = verbose
        self.scripts: Dict[str, Dict] = {}
        self.file_hashes: Dict[str, str] = {}
        self.variables: Dict[str, any] = {}
        self.subscripts: Dict[str, callable] = {}
        self.triggers: Dict[str, callable] = {}
        self.running = False
        self.watch_thread = None
    
    def log(self, message: str, level: str = "INFO"):
        """Log a message"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        prefix = f"[{timestamp}] [{level}]"
        print(f"{prefix} {message}")
    
    def _calculate_hash(self, file_path: Path) -> str:
        """Calculate file hash for change detection"""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    
    def load_script(self, file_path: Path) -> bool:
        """Load and parse a .pks file"""
        try:
            if self.verbose:
                self.log(f"Loading script: {file_path.name}", "LOAD")
            
            # Read the file
            with open(file_path, 'r', encoding='utf-8') as f:
                source = f.read()
            
            # Tokenize and parse
            lexer = Lexer(source)
            tokens = lexer.tokenize()
            parser = Parser(tokens)
            ast = parser.parse()
            
            # Store the script
            self.scripts[str(file_path)] = {
                'ast': ast,
                'path': file_path,
                'loaded_at': datetime.now(),
                'source': source
            }
            
            # Update hash
            self.file_hashes[str(file_path)] = self._calculate_hash(file_path)
            
            self.log(f"✓ Loaded: {file_path.name}", "SUCCESS")
            return True
        
        except Exception as e:
            self.log(f"✗ Error loading {file_path.name}: {e}", "ERROR")
            if self.verbose:
                traceback.print_exc()
            return False
    
    def execute_script(self, file_path: Path) -> bool:
        """Execute a loaded script"""
        try:
            file_key = str(file_path)
            
            if file_key not in self.scripts:
                self.log(f"Script not loaded: {file_path.name}", "WARN")
                return False
            
            script_info = self.scripts[file_key]
            ast = script_info['ast']
            
            if self.verbose:
                self.log(f"Executing: {file_path.name}", "EXEC")
            
            # Execute statements from the script
            self._execute_statements(ast.script.statements)
            
            self.log(f"✓ Executed: {file_path.name}", "SUCCESS")
            return True
        
        except Exception as e:
            self.log(f"✗ Error executing {file_path.name}: {e}", "ERROR")
            if self.verbose:
                traceback.print_exc()
            return False
    
    def _execute_statements(self, statements: List):
        """Execute a list of statements"""
        for stmt in statements:
            self._execute_statement(stmt)
    
    def _execute_statement(self, stmt):
        """Execute a single statement"""
        stmt_type = type(stmt).__name__
        
        if stmt_type == 'FunctionCall':
            self._execute_function_call(stmt)
        elif stmt_type == 'Assignment':
            self._execute_assignment(stmt)
        elif stmt_type == 'IfStatement':
            self._execute_if_statement(stmt)
        elif stmt_type == 'WhileStatement':
            self._execute_while_statement(stmt)
        elif stmt_type == 'ForStatement':
            self._execute_for_statement(stmt)
        elif stmt_type == 'RunStatement':
            self._execute_run_statement(stmt)
    
    def _execute_function_call(self, call):
        """Execute a function call"""
        if call.name == "log.print":
            args = [self._evaluate_expression(arg) for arg in call.arguments]
            print(*args)
        elif call.name in self.subscripts:
            # Call subscript
            self.subscripts[call.name]()
    
    def _execute_assignment(self, assign):
        """Execute an assignment"""
        value = self._evaluate_expression(assign.value)
        self.variables[assign.var_name] = value
    
    def _execute_if_statement(self, if_stmt):
        """Execute an if statement"""
        condition = self._evaluate_expression(if_stmt.condition)
        if condition:
            self._execute_statements(if_stmt.then_block)
        elif if_stmt.else_block:
            self._execute_statements(if_stmt.else_block)
    
    def _execute_while_statement(self, while_stmt):
        """Execute a while loop"""
        while self._evaluate_expression(while_stmt.condition):
            self._execute_statements(while_stmt.body)
    
    def _execute_for_statement(self, for_stmt):
        """Execute a for loop"""
        start = int(self._evaluate_expression(for_stmt.start))
        end = int(self._evaluate_expression(for_stmt.end))
        for i in range(start, end):
            self.variables[for_stmt.var_name] = i
            self._execute_statements(for_stmt.body)
    
    def _execute_run_statement(self, run_stmt):
        """Execute a run statement"""
        # Get trigger name
        trigger_name = self._evaluate_expression(run_stmt.target)
        if trigger_name in self.triggers:
            self.triggers[trigger_name]()
    
    def _evaluate_expression(self, expr):
        """Evaluate an expression"""
        expr_type = type(expr).__name__
        
        if expr_type == 'Literal':
            return expr.value
        elif expr_type == 'Variable':
            return self.variables.get(expr.name, None)
        elif expr_type == 'BinaryOp':
            left = self._evaluate_expression(expr.left)
            right = self._evaluate_expression(expr.right)
            
            if expr.op == '+':
                return left + right
            elif expr.op == '-':
                return left - right
            elif expr.op == '*':
                return left * right
            elif expr.op == '/':
                return left / right
            elif expr.op == '%':
                return left % right
            elif expr.op == '==':
                return left == right
            elif expr.op == '!=':
                return left != right
            elif expr.op == '<':
                return left < right
            elif expr.op == '>':
                return left > right
            elif expr.op == '<=':
                return left <= right
            elif expr.op == '>=':
                return left >= right
            elif expr.op == '&&':
                return left and right
            elif expr.op == '||':
                return left or right
        elif expr_type == 'UnaryOp':
            operand = self._evaluate_expression(expr.operand)
            if expr.op == '-':
                return -operand
            elif expr.op == '!':
                return not operand
        elif expr_type == 'MethodCall':
            if expr.name == 'print':
                args = [self._evaluate_expression(arg) for arg in expr.arguments]
                return str(*args)
        
        return None
    
    def watch_directory(self):
        """Watch directory for changes and reload scripts"""
        if self.verbose:
            self.log(f"Watching directory: {self.watch_dir}", "WATCH")
        
        while self.running:
            try:
                # Find all .pks files
                pks_files = list(self.watch_dir.glob("**/*.pks"))
                
                for file_path in pks_files:
                    file_key = str(file_path)
                    current_hash = self._calculate_hash(file_path)
                    
                    # Check if file is new or modified
                    if file_key not in self.file_hashes or self.file_hashes[file_key] != current_hash:
                        self.load_script(file_path)
                        self.execute_script(file_path)
                
                time.sleep(1)  # Check every second
            
            except Exception as e:
                self.log(f"Watcher error: {e}", "ERROR")
                time.sleep(2)
    
    def start_watching(self):
        """Start watching directory in background"""
        if self.watch_thread is not None:
            self.log("Already watching directory", "WARN")
            return
        
        self.running = True
        self.watch_thread = threading.Thread(target=self.watch_directory, daemon=True)
        self.watch_thread.start()
        self.log("Started real-time script loader", "START")
    
    def stop_watching(self):
        """Stop watching directory"""
        self.running = False
        if self.watch_thread:
            self.watch_thread.join(timeout=5)
        self.log("Stopped real-time script loader", "STOP")
    
    def load_all_scripts(self):
        """Load all .pks files in watch directory"""
        self.log(f"Loading all scripts from {self.watch_dir}", "LOAD")
        
        pks_files = list(self.watch_dir.glob("**/*.pks"))
        loaded = 0
        
        for file_path in pks_files:
            if self.load_script(file_path):
                loaded += 1
        
        self.log(f"Loaded {loaded} script(s)", "INFO")
        return loaded
    
    def execute_all_scripts(self):
        """Execute all loaded scripts"""
        self.log(f"Executing {len(self.scripts)} script(s)", "EXEC")
        
        executed = 0
        for file_path in self.scripts.keys():
            if self.execute_script(Path(file_path)):
                executed += 1
        
        self.log(f"Executed {executed} script(s)", "INFO")
        return executed
    
    def get_variables(self) -> Dict:
        """Get all variables"""
        return self.variables.copy()
    
    def get_subscripts(self) -> List[str]:
        """Get all subscript names"""
        return list(self.subscripts.keys())
    
    def get_triggers(self) -> List[str]:
        """Get all trigger names"""
        return list(self.triggers.keys())
    
    def status(self) -> Dict:
        """Get runtime status"""
        return {
            'running': self.running,
            'watch_directory': str(self.watch_dir),
            'loaded_scripts': len(self.scripts),
            'variables': len(self.variables),
            'subscripts': len(self.subscripts),
            'triggers': len(self.triggers),
            'scripts': list(self.scripts.keys())
        }

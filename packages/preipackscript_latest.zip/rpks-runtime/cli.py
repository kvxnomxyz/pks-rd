"""
RawPKS Command-Line Interface
Real-time PackScript loader with hot-reload support
"""
import sys
import argparse
import os
from pathlib import Path
from .runtime import RPKSRuntime


class RPKSCli:
    def __init__(self):
        self.runtime = None
    
    def init_runtime(self, watch_dir: str = None, verbose: bool = False):
        """Initialize the runtime"""
        if self.runtime is None:
            self.runtime = RPKSRuntime(watch_dir=watch_dir, verbose=verbose)
    
    def cmd_start(self, args):
        """Start real-time loader"""
        self.init_runtime(args.directory, args.verbose)
        
        print("=" * 60)
        print("RawPKS - Real-Time PackScript Loader")
        print("=" * 60)
        print(f"Watch directory: {self.runtime.watch_dir}")
        print(f"Verbose mode: {args.verbose}")
        print()
        
        # Load all existing scripts
        self.runtime.load_all_scripts()
        
        # Start watching
        self.runtime.start_watching()
        
        try:
            print("\nWatching for changes... (Press Ctrl+C to stop)")
            print()
            
            while True:
                import time
                time.sleep(1)
        
        except KeyboardInterrupt:
            print("\n\nShutting down...")
            self.runtime.stop_watching()
            print("✓ Stopped")
    
    def cmd_run(self, args):
        """Run a single script"""
        self.init_runtime(verbose=args.verbose)
        
        script_path = Path(args.script)
        
        if not script_path.exists():
            print(f"Error: Script not found: {script_path}")
            sys.exit(1)
        
        print(f"Running: {script_path.name}")
        
        if self.runtime.load_script(script_path):
            self.runtime.execute_script(script_path)
        else:
            sys.exit(1)
    
    def cmd_load(self, args):
        """Load scripts from directory"""
        self.init_runtime(args.directory, args.verbose)
        
        loaded = self.runtime.load_all_scripts()
        print(f"✓ Loaded {loaded} script(s)")
    
    def cmd_execute(self, args):
        """Execute all loaded scripts"""
        self.init_runtime(args.directory, args.verbose)
        
        self.runtime.load_all_scripts()
        executed = self.runtime.execute_all_scripts()
        
        print(f"✓ Executed {executed} script(s)")
    
    def cmd_status(self, args):
        """Show runtime status"""
        self.init_runtime(args.directory)
        
        status = self.runtime.status()
        
        print("\nRawPKS Runtime Status")
        print("-" * 60)
        print(f"Running: {status['running']}")
        print(f"Watch Directory: {status['watch_directory']}")
        print(f"Loaded Scripts: {status['loaded_scripts']}")
        print(f"Variables: {status['variables']}")
        print(f"Subscripts: {status['subscripts']}")
        print(f"Triggers: {status['triggers']}")
        
        if status['scripts']:
            print(f"\nScripts:")
            for script in status['scripts']:
                print(f"  - {script}")
        
        print()
    
    def cmd_list_vars(self, args):
        """List all variables"""
        self.init_runtime(args.directory)
        
        variables = self.runtime.get_variables()
        
        if not variables:
            print("No variables defined")
            return
        
        print("\nVariables:")
        print("-" * 60)
        for name, value in variables.items():
            print(f"  {name} = {value}")
        print()


def main():
    parser = argparse.ArgumentParser(
        description="RawPKS - Real-Time PackScript Loader",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  rpks start                       Start real-time loader
  rpks start -d ./scripts          Watch custom directory
  rpks run mymod.pks               Execute single script
  rpks load                        Load all scripts
  rpks execute                     Load and execute all scripts
  rpks status                      Show runtime status
  rpks vars                        List all variables
"""
    )
    
    parser.add_argument(
        "-d", "--directory",
        help="Watch directory (default: ~/.packscript/scripts)",
        default=None
    )
    
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Start command
    start_parser = subparsers.add_parser("start", help="Start real-time loader")
    start_parser.set_defaults(func=lambda args: RPKSCli().cmd_start(args))
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run a single script")
    run_parser.add_argument("script", help="Script file to run")
    run_parser.set_defaults(func=lambda args: RPKSCli().cmd_run(args))
    
    # Load command
    load_parser = subparsers.add_parser("load", help="Load all scripts")
    load_parser.set_defaults(func=lambda args: RPKSCli().cmd_load(args))
    
    # Execute command
    exec_parser = subparsers.add_parser("execute", help="Load and execute scripts")
    exec_parser.set_defaults(func=lambda args: RPKSCli().cmd_execute(args))
    
    # Status command
    status_parser = subparsers.add_parser("status", help="Show runtime status")
    status_parser.set_defaults(func=lambda args: RPKSCli().cmd_status(args))
    
    # Variables command
    vars_parser = subparsers.add_parser("vars", help="List variables")
    vars_parser.set_defaults(func=lambda args: RPKSCli().cmd_list_vars(args))
    
    args = parser.parse_args()
    
    if not hasattr(args, 'func'):
        parser.print_help()
        sys.exit(0)
    
    args.func(args)


if __name__ == "__main__":
    main()

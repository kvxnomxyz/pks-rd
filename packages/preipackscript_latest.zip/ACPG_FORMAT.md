# .acpg File Format Reference

**ACPG** = **Advanced Compressed Package** Format

## Overview

ACPG is the standard package format for PackScript packages and distribution. It's optimized for efficient storage, distribution, and version management.

### Key Features
- ✅ ZIP archive format (portable and widely supported)
- ✅ JSON metadata with package information
- ✅ SHA256 integrity verification
- ✅ Version management and multi-version support
- ✅ Dependency tracking
- ✅ Self-contained and relocatable
- ✅ Cross-platform compatible

## File Structure

### Basic Structure
```
mypackage.acpg
├── package.json          [Required]
├── module.pks           [PackScript source files]
├── utils.pks
└── README.md            [Recommended]
```

### Directory-based Packages
```
mypackage.acpg
├── package.json
├── src/
│   ├── main.pks
│   ├── utils.pks
│   └── helpers.pks
├── docs/
│   └── guide.md
└── README.md
```

## package.json Specification

The `package.json` file is **required** and must be located at the root of the archive.

### Required Fields

```json
{
  "name": "string",           // Package identifier (lowercase, no spaces)
  "version": "string",        // Semantic versioning (1.0.0)
  "author": "string",         // Author or organization name
  "description": "string",    // One-line description
  "dependencies": []          // Array of package dependencies
}
```

### Full Format

```json
{
  "name": "easylog",
  "version": "1.0.0",
  "author": "PackScript Team",
  "description": "Easy logging utilities for PackScript",
  "dependencies": [],
  "repository": {
    "type": "git",
    "url": "https://github.com/user/repo"
  },
  "keywords": ["logging", "utilities"],
  "license": "MIT",
  "files": ["*.pks", "README.md"],
  "main": "main.pks",
  "exports": {
    "log": "log.pks"
  }
}
```

### Field Descriptions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | ✓ | Unique package identifier |
| `version` | string | ✓ | Semantic version (MAJOR.MINOR.PATCH) |
| `author` | string | ✓ | Author or organization |
| `description` | string | ✓ | Short description |
| `dependencies` | array | ✓ | Required packages (can be empty) |
| `license` | string | ✗ | License type (MIT, Apache, etc.) |
| `repository` | object | ✗ | Version control repository |
| `keywords` | array | ✗ | Search keywords |
| `files` | array | ✗ | Files to include (defaults to all) |
| `main` | string | ✗ | Entry point file |
| `exports` | object | ✗ | Named exports |

## Creating ACPG Files

### Method 1: Using packager.py (Recommended)

```bash
python packages/packager.py packages/mypackage dist/mypackage.acpg
```

### Method 2: Using Python

```python
from packages.packager import create_package

create_package(
    source_dir="packages/mypackage",
    output_file="dist/mypackage.acpg",
    verbose=True
)
```

### Method 3: Manual Creation with ZIP

```bash
# Linux/macOS
cd packages/mypackage
zip -r ../../dist/mypackage.acpg .

# Windows (PowerShell)
Compress-Archive -Path packages/mypackage/* -DestinationPath dist/mypackage.acpg
```

### Method 4: Python zipfile

```python
import zipfile
import os

def create_acpg(source_dir, output_file):
    with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, source_dir)
                zipf.write(file_path, arcname)

create_acpg('packages/mypackage', 'dist/mypackage.acpg')
```

## Installation

### Via Ducky Package Manager (Recommended)

```bash
ducky install mypackage
ducky install mypackage@1.0.0  # Specific version
```

### Manual Installation

```bash
# Extract package
unzip mypackage.acpg -d ~/.ducky/packages/mypackage

# Or on Windows
Expand-Archive -Path mypackage.acpg -DestinationPath $env:USERPROFILE\.ducky\packages\mypackage
```

## Distribution

### Host on GitHub

1. Create repository: `https://github.com/user/pks-repo`
2. Create `/packages/` directory
3. Create `/package-repositories.json` index
4. Upload ACPG files to `/packages/`
5. Reference in repository configuration

### Repository Index Format

```json
{
  "mypackage": {
    "name": "mypackage",
    "version": "1.0.0",
    "author": "Author Name",
    "description": "Package description",
    "url": "https://raw.githubusercontent.com/user/repo/packages/mypackage.acpg",
    "dependencies": [],
    "versions": {
      "1.0.0": {
        "url": "https://raw.githubusercontent.com/user/repo/packages/mypackage.acpg",
        "checksum": "auto"
      }
    }
  }
}
```

### Default Repository URL

```
https://raw.githubusercontent.com/kvxnomxyz/pks-rd/package-repositories.json
```

## Verification

### Check ACPG Contents

```bash
unzip -l mypackage.acpg
```

### Verify Integrity

```python
import zipfile
import json

def verify_acpg(filepath):
    try:
        with zipfile.ZipFile(filepath, 'r') as z:
            # Check package.json exists
            if 'package.json' not in z.namelist():
                print("❌ Missing package.json")
                return False
            
            # Load metadata
            with z.open('package.json') as f:
                metadata = json.load(f)
            
            print(f"✓ Package: {metadata['name']}")
            print(f"✓ Version: {metadata['version']}")
            print(f"✓ Files: {len(z.namelist())}")
            return True
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

verify_acpg('mypackage.acpg')
```

### Size Optimization

```python
# Check compression ratio
import os
import zipfile

def check_size(filepath):
    file_size = os.path.getsize(filepath)
    
    with zipfile.ZipFile(filepath, 'r') as z:
        uncompressed = sum(info.file_size for info in z.infolist())
    
    ratio = (1 - file_size / uncompressed) * 100 if uncompressed > 0 else 0
    print(f"Compressed: {file_size:,} bytes")
    print(f"Uncompressed: {uncompressed:,} bytes")
    print(f"Ratio: {ratio:.1f}% compression")
```

## Version Management

### Semantic Versioning

Follow **Semantic Versioning 2.0.0**:

```
MAJOR.MINOR.PATCH

Examples:
1.0.0        # First release
1.1.0        # Minor version (new features)
1.1.1        # Patch version (bug fixes)
2.0.0        # Major version (breaking changes)
```

### Multi-Version Support

```json
{
  "name": "chat",
  "version": "1.2.0",
  "url": "https://raw.githubusercontent.com/kvxnomxyz/pks-rd/packages/chat.acpg",
  "versions": {
    "1.1.0": {
      "url": "https://raw.githubusercontent.com/kvxnomxyz/pks-rd/packages/chat-1.1.0.acpg"
    },
    "1.2.0": {
      "url": "https://raw.githubusercontent.com/kvxnomxyz/pks-rd/packages/chat.acpg"
    }
  }
}
```

### Installation by Version

```bash
ducky install chat              # Latest
ducky install chat@1.1.0        # Specific version
ducky install chat@1.x          # Latest 1.x
```

## Best Practices

### 1. Package Organization
- Keep related functionality together
- Use clear naming conventions
- Include README for complex packages
- Document all exported functions

### 2. Metadata Quality
- Use descriptive package names
- Write clear descriptions (max 100 chars)
- List all actual dependencies
- Keep versions consistent

### 3. File Selection
- Include only necessary files
- Use `.gitignore` equivalents
- Exclude build artifacts
- Exclude version control directories

```json
"files": [
  "*.pks",
  "README.md",
  "LICENSE"
]
```

### 4. Dependency Management
- Be specific with versions when needed
- List only direct dependencies
- Document any platform-specific requirements
- Use version constraints

```json
"dependencies": [
  "logging>=1.0.0",
  "utils",
  "minecraft-forge"
]
```

### 5. Documentation
- Include README.md in package
- Document functions and usage
- Provide examples
- List any dependencies

### 6. Testing
- Test package extraction
- Verify SHA256 checksums
- Test on multiple platforms
- Document known issues

## Troubleshooting

### Package Installation Fails
```bash
# Check file integrity
unzip -t mypackage.acpg

# Verify package.json
python -m json.tool packages/mypackage/package.json
```

### Checksum Mismatch
```python
import hashlib
import zipfile

def get_checksum(filepath):
    with open(filepath, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()

print(get_checksum('mypackage.acpg'))
```

### Repository Index Issues
```bash
# Verify repository URL
curl https://raw.githubusercontent.com/kvxnomxyz/pks-rd/package-repositories.json

# Pretty print
python -m json.tool < package-repositories.json
```

## Migration from .ppkg to .acpg

The ACPG format is fully backward compatible at the technical level (both are ZIP archives), but with improved naming:

### ACPG Advantages
- ✅ More descriptive format name
- ✅ Better indicates "Advanced Compressed Package"
- ✅ Improved documentation
- ✅ Enhanced tooling

### Migration Steps
```bash
# Rename files
mv old.ppkg new.acpg

# Update repository index
# Change URLs from *.ppkg to *.acpg

# Test installation
ducky install new
```

## Implementation Details

### Extraction Process

```python
def install_acpg_package(acpg_path, install_dir):
    import zipfile
    import json
    from pathlib import Path
    
    Path(install_dir).mkdir(parents=True, exist_ok=True)
    
    with zipfile.ZipFile(acpg_path, 'r') as z:
        # Verify metadata
        if 'package.json' not in z.namelist():
            raise ValueError("Invalid ACPG: missing package.json")
        
        # Extract all files
        z.extractall(install_dir)
        
        # Return metadata
        with z.open('package.json') as f:
            return json.load(f)
```

### Checksum Verification

```python
def verify_checksum(acpg_path, expected_checksum):
    import hashlib
    
    sha256 = hashlib.sha256()
    with open(acpg_path, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b''):
            sha256.update(chunk)
    
    actual = sha256.hexdigest()
    return actual == expected_checksum
```

---

**Last Updated**: April 2026
**Format Version**: 1.0
**Specification URL**: Reference PackScript documentation for latest versions

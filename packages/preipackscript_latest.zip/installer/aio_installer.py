"""
PackScript All-in-One Installer with CLI/GUI Interface
Supports both command-line and graphical user interface options
"""

import sys
import os
import json
import zipfile
import shutil
import subprocess
import urllib.request
import urllib.error
import hashlib
import platform
from pathlib import Path
from typing import Optional

# Optional GUI imports (graceful fallback if tkinter unavailable)
try:
    import tkinter as tk
    from tkinter import messagebox, filedialog, ttk
    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False


class PacklistInstaller:
    """Core installation logic"""
    
    DUCKY_DOWNLOAD_URL = "https://raw.githubusercontent.com/kvxnomxyz/pks-rd/packages/ducky.zip.acpg"
    REPO_INDEX_URL = "https://raw.githubusercontent.com/kvxnomxyz/pks-rd/package-repositories.json"
    
    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.os_type = platform.system()
        self.home = str(Path.home())
        self.ducky_home = os.path.join(self.home, ".ducky")
        self.packscript_home = os.path.join(self.home, ".packscript")
        self.install_success = False
        self.messages = []
    
    def log(self, message: str, level: str = "INFO"):
        """Log messages"""
        formatted = f"[{level}] {message}"
        self.messages.append(formatted)
        if self.verbose:
            print(formatted)
    
    def get_messages(self) -> str:
        """Get all logged messages"""
        return "\n".join(self.messages)
    
    def verify_installation_requirements(self) -> bool:
        """Check if system meets requirements"""
        try:
            self.log("Checking installation requirements...")
            
            # Check Python version
            if sys.version_info < (3, 8):
                self.log("Python 3.8 or higher is required", "ERROR")
                return False
            
            self.log(f"✓ Python {sys.version_info.major}.{sys.version_info.minor}")
            
            # Check OS compatibility
            if self.os_type not in ["Windows", "Linux", "Darwin"]:
                self.log(f"Unsupported OS: {self.os_type}", "ERROR")
                return False
            
            self.log(f"✓ OS: {self.os_type}")
            
            # Check write permissions
            test_file = os.path.join(self.home, ".packscript_test")
            try:
                Path(test_file).touch()
                os.remove(test_file)
                self.log("✓ Write permissions OK")
            except PermissionError:
                self.log("No write permissions in home directory", "ERROR")
                return False
            
            return True
        
        except Exception as e:
            self.log(f"Requirement check failed: {e}", "ERROR")
            return False
    
    def download_ducky(self) -> Optional[str]:
        """Download Ducky package manager"""
        try:
            self.log("Downloading Ducky package manager...")
            
            cache_dir = os.path.join(self.home, ".packscript", "cache")
            os.makedirs(cache_dir, exist_ok=True)
            
            download_path = os.path.join(cache_dir, "ducky.zip.acpg")
            
            # Download with progress
            def reporthook(blocknum, blocksize, totalsize):
                if totalsize > 0:
                    downloaded = blocknum * blocksize
                    percent = min(100, (downloaded * 100) // totalsize)
                    self.log(f"  Downloaded: {percent}%")
            
            self.log(f"Fetching from: {self.DUCKY_DOWNLOAD_URL}")
            urllib.request.urlretrieve(self.DUCKY_DOWNLOAD_URL, download_path, reporthook)
            
            self.log("✓ Ducky downloaded successfully")
            return download_path
        
        except Exception as e:
            self.log(f"Failed to download Ducky: {e}", "ERROR")
            return None
    
    def extract_ducky(self, acpg_path: str) -> bool:
        """Extract Ducky from ACPG file"""
        try:
            self.log("Extracting Ducky...")
            
            os.makedirs(self.ducky_home, exist_ok=True)
            
            with zipfile.ZipFile(acpg_path, 'r') as zip_ref:
                zip_ref.extractall(self.ducky_home)
            
            self.log(f"✓ Extracted to {self.ducky_home}")
            return True
        
        except Exception as e:
            self.log(f"Failed to extract Ducky: {e}", "ERROR")
            return False
    
    def setup_environment(self) -> bool:
        """Setup environment variables and PATH"""
        try:
            self.log("Setting up environment...")
            
            if self.os_type == "Windows":
                return self._setup_windows_env()
            else:
                return self._setup_unix_env()
        
        except Exception as e:
            self.log(f"Failed to setup environment: {e}", "ERROR")
            return False
    
    def _setup_windows_env(self) -> bool:
        """Setup Windows environment (registry)"""
        try:
            self.log("Configuring Windows environment...")
            
            # Set environment variables using setx
            ducky_path = os.path.join(self.ducky_home, "bin")
            
            # Note: setx requires regex escaping
            subprocess.run(["setx", "DUCKY_HOME", self.ducky_home], 
                          capture_output=True, check=True)
            subprocess.run(["setx", "PACKSCRIPT_HOME", self.packscript_home], 
                          capture_output=True, check=True)
            
            self.log("✓ Environment variables set (DUCKY_HOME, PACKSCRIPT_HOME)")
            self.log("✓ Please restart your terminal for PATH changes to take effect")
            return True
        
        except Exception as e:
            self.log(f"Windows environment setup: {e}", "WARNING")
            return True  # Don't fail, as it might still work
    
    def _setup_unix_env(self) -> bool:
        """Setup Unix/Linux/macOS environment"""
        try:
            self.log("Configuring Unix environment...")
            
            shell_profile = None
            if os.path.exists(os.path.expanduser("~/.zshrc")):
                shell_profile = os.path.expanduser("~/.zshrc")
                shell = "zsh"
            elif os.path.exists(os.path.expanduser("~/.bash_profile")):
                shell_profile = os.path.expanduser("~/.bash_profile")
                shell = "bash"
            elif os.path.exists(os.path.expanduser("~/.bashrc")):
                shell_profile = os.path.expanduser("~/.bashrc")
                shell = "bash"
            else:
                self.log("Could not find shell profile", "WARNING")
                return True
            
            # Read current profile
            with open(shell_profile, 'r') as f:
                content = f.read()
            
            # Only add if not already present
            export_line = f'export DUCKY_HOME="{self.ducky_home}"'
            if "DUCKY_HOME" not in content:
                content += f"\n\n# PackScript Environment\n{export_line}\n"
                with open(shell_profile, 'w') as f:
                    f.write(content)
                self.log(f"✓ Updated {shell} profile ({shell_profile})")
            else:
                self.log(f"✓ Already configured in {shell_profile}")
            
            return True
        
        except Exception as e:
            self.log(f"Unix environment setup: {e}", "WARNING")
            return True
    
    def download_repository_index(self) -> Optional[dict]:
        """Download the package repository index"""
        try:
            self.log("Downloading package repository index...")
            with urllib.request.urlopen(self.REPO_INDEX_URL, timeout=10) as response:
                data = json.loads(response.read().decode('utf-8'))
                self.log(f"✓ Retrieved {len(data)} packages from repository")
                return data
        except Exception as e:
            self.log(f"Could not download repository index: {e}", "WARNING")
            return None
    
    def install(self) -> bool:
        """Perform full installation"""
        try:
            steps = [
                ("Verify Requirements", self.verify_installation_requirements),
                ("Download Ducky", lambda: self.download_ducky() is not None),
                ("Extract Files", lambda: self.extract_ducky(self.download_ducky() or "")),
                ("Setup Environment", self.setup_environment),
                ("Download Repository", lambda: self.download_repository_index() is not None),
            ]
            
            for step_name, step_func in steps:
                self.log(f"\n{'='*50}")
                self.log(f"Step: {step_name}")
                self.log('='*50)
                
                if not step_func():
                    self.log(f"✗ Installation failed at: {step_name}", "ERROR")
                    return False
            
            self.log("\n" + "="*50)
            self.log("✓ INSTALLATION COMPLETE!", "SUCCESS")
            self.log("="*50)
            self.log("\nNext steps:")
            self.log("1. Restart your terminal")
            self.log("2. Run: ducky list")
            self.log("3. Start using PackScript!")
            
            self.install_success = True
            return True
        
        except Exception as e:
            self.log(f"Installation error: {e}", "ERROR")
            return False


class CLIInstaller:
    """Command-line interface for installation"""
    
    def run(self, verbose: bool = False):
        """Run CLI installation"""
        installer = PacklistInstaller(verbose)
        
        print("\n" + "="*60)
        print("  PackScript All-in-One Installer (CLI Mode)")
        print("="*60 + "\n")
        
        result = installer.install()
        
        print("\n" + installer.get_messages())
        
        if not result:
            print("\n⚠ Installation encountered issues")
            sys.exit(1)
        else:
            print("\n✓ Installation successful!")
            sys.exit(0)


class GUIInstaller:
    """Graphical user interface for installation"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("PackScript Installer")
        self.root.geometry("600x700")
        self.root.resizable(False, False)
        
        self.installer = None
        self.text_output = None
        self.progress = None
        self.button_install = None
    
    def setup_ui(self):
        """Create GUI components"""
        # Title
        title_frame = tk.Frame(self.root, bg="#2c3e50", height=80)
        title_frame.pack(fill=tk.X)
        
        title_label = tk.Label(
            title_frame,
            text="PackScript Installer",
            font=("Helvetica", 24, "bold"),
            bg="#2c3e50",
            fg="white"
        )
        title_label.pack(pady=15)
        
        subtitle_label = tk.Label(
            title_frame,
            text="All-in-One Package Installation",
            font=("Helvetica", 11),
            bg="#2c3e50",
            fg="#ecf0f1"
        )
        subtitle_label.pack()
        
        # Main frame
        main_frame = tk.Frame(self.root, bg="white")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        # Info label
        info_label = tk.Label(
            main_frame,
            text="Installation Progress:",
            font=("Helvetica", 11, "bold"),
            bg="white",
            justify=tk.LEFT
        )
        info_label.pack(anchor=tk.W, pady=(0, 10))
        
        # Output text
        output_frame = tk.Frame(main_frame, bg="white")
        output_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        scrollbar = tk.Scrollbar(output_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.text_output = tk.Text(
            output_frame,
            height=20,
            width=60,
            font=("Courier", 9),
            bg="#ecf0f1",
            fg="#2c3e50",
            yscrollcommand=scrollbar.set
        )
        self.text_output.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.text_output.yview)
        
        # Progress bar
        self.progress = ttk.Progressbar(
            main_frame,
            mode='indeterminate',
            length=400
        )
        self.progress.pack(pady=(0, 15))
        
        # Buttons frame
        button_frame = tk.Frame(main_frame, bg="white")
        button_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.button_install = tk.Button(
            button_frame,
            text="Install",
            command=self.start_installation,
            font=("Helvetica", 11),
            bg="#27ae60",
            fg="white",
            padx=20,
            pady=10,
            cursor="hand2"
        )
        self.button_install.pack(side=tk.LEFT, padx=(0, 10))
        
        close_button = tk.Button(
            button_frame,
            text="Close",
            command=self.root.quit,
            font=("Helvetica", 11),
            bg="#95a5a6",
            fg="white",
            padx=20,
            pady=10,
            cursor="hand2"
        )
        close_button.pack(side=tk.LEFT)
    
    def log_output(self, message: str, tag: str = "normal"):
        """Add text to output"""
        self.text_output.insert(tk.END, message + "\n")
        self.text_output.see(tk.END)
        self.root.update()
    
    def start_installation(self):
        """Start the installation process"""
        self.text_output.delete(1.0, tk.END)
        self.button_install.config(state=tk.DISABLED)
        self.progress.start()
        
        self.installer = PacklistInstaller(verbose=True)
        
        # Override logger to use GUI
        original_log = self.installer.log
        self.installer.log = lambda msg, level="INFO": (
            original_log(msg, level),
            self.log_output(f"[{level}] {msg}")
        )
        
        # Run installation
        result = self.installer.install()
        
        self.progress.stop()
        self.button_install.config(state=tk.NORMAL)
        
        if result:
            messagebox.showinfo(
                "Success",
                "Installation completed successfully!\n\n" +
                "Please restart your terminal and run: ducky list"
            )
        else:
            messagebox.showerror(
                "Error",
                "Installation failed.\n\nCheck the output for details."
            )
    
    def run(self):
        """Run the GUI installer"""
        self.setup_ui()
        self.root.mainloop()


class AioInstaller:
    """Main entry point for All-in-One installer"""
    
    @staticmethod
    def main():
        """Main entry point"""
        import argparse
        
        parser = argparse.ArgumentParser(
            description="PackScript All-in-One Installer (CLI/GUI)"
        )
        parser.add_argument(
            "--cli",
            action="store_true",
            help="Use command-line interface"
        )
        parser.add_argument(
            "--gui",
            action="store_true",
            help="Use graphical interface (default if available)"
        )
        parser.add_argument(
            "--verbose", "-v",
            action="store_true",
            help="Verbose output"
        )
        
        args = parser.parse_args()
        
        # Decide which mode to use
        use_gui = args.gui or (not args.cli and GUI_AVAILABLE)
        
        if use_gui and GUI_AVAILABLE:
            installer = GUIInstaller()
            installer.run()
        else:
            installer = CLIInstaller()
            installer.run(args.verbose)


if __name__ == "__main__":
    AioInstaller.main()

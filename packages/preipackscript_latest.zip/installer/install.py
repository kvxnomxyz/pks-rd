"""
PackScript Installer - Downloads and installs Ducky
"""
import os
import sys
import zipfile
import shutil
import urllib.request
from pathlib import Path

class PackScriptInstaller:
    def __init__(self):
        self.ducky_url = "https://raw.githubusercontent.com/kvxnomxyz/pks-rd/packages/ducky.zip.ppkg"
        self.install_dir = os.path.join(os.path.expanduser("~"), ".packscript")
        self.ducky_dir = os.path.join(self.install_dir, "ducky")
    
    def download_ducky(self) -> str:
        """Download Ducky package manager"""
        os.makedirs(self.install_dir, exist_ok=True)
        
        ducky_zip = os.path.join(self.install_dir, "ducky.zip")
        
        print(f"Downloading Ducky from {self.ducky_url}...")
        
        try:
            urllib.request.urlretrieve(self.ducky_url, ducky_zip)
            print(f"✓ Downloaded to {ducky_zip}")
            return ducky_zip
        except Exception as e:
            print(f"Error downloading Ducky: {e}")
            sys.exit(1)
    
    def extract_ducky(self, ducky_zip: str):
        """Extract Ducky to installation directory"""
        print(f"Extracting Ducky...")
        
        # Remove old ducky directory if it exists
        if os.path.exists(self.ducky_dir):
            shutil.rmtree(self.ducky_dir)
        
        try:
            with zipfile.ZipFile(ducky_zip, 'r') as zip_ref:
                zip_ref.extractall(self.ducky_dir)
            print(f"✓ Extracted to {self.ducky_dir}")
        except Exception as e:
            print(f"Error extracting Ducky: {e}")
            sys.exit(1)
    
    def add_to_path(self):
        """Add Ducky to environment PATH"""
        print(f"Adding Ducky to PATH...")
        
        ducky_bin = os.path.join(self.ducky_dir, "bin")
        
        # Set environment variable
        os.environ['DUCKY_HOME'] = self.ducky_dir
        os.environ['PATH'] = ducky_bin + os.pathsep + os.environ.get('PATH', '')
        
        # For Windows, update user environment variables permanently
        if sys.platform == 'win32':
            try:
                import winreg
                
                # Add to User environment variables
                reg_path = r"Environment"
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path)
                
                # Set DUCKY_HOME
                winreg.SetValueEx(key, 'DUCKY_HOME', 0, winreg.REG_SZ, self.ducky_dir)
                
                # Update PATH
                current_path = winreg.QueryValueEx(key, 'Path')[0]
                if ducky_bin not in current_path:
                    new_path = ducky_bin + ';' + current_path
                    winreg.SetValueEx(key, 'Path', 0, winreg.REG_EXPAND_SZ, new_path)
                
                winreg.CloseKey(key)
                print(f"✓ Environment variables updated")
            except Exception as e:
                print(f"Warning: Could not update system environment: {e}")
        
        # For Linux/Mac, update shell profiles
        else:
            home = os.path.expanduser("~")
            
            # Update .bashrc
            bashrc = os.path.join(home, ".bashrc")
            if os.path.exists(bashrc):
                with open(bashrc, 'a') as f:
                    f.write(f"\n# PackScript Ducky\nexport DUCKY_HOME={self.ducky_dir}\nexport PATH=$DUCKY_HOME/bin:$PATH\n")
            
            # Update .zshrc
            zshrc = os.path.join(home, ".zshrc")
            if os.path.exists(zshrc):
                with open(zshrc, 'a') as f:
                    f.write(f"\n# PackScript Ducky\nexport DUCKY_HOME={self.ducky_dir}\nexport PATH=$DUCKY_HOME/bin:$PATH\n")
            
            print(f"✓ Shell profiles updated")
    
    def install(self):
        """Run the full installation"""
        print("=" * 60)
        print("PackScript + Ducky Installer")
        print("=" * 60)
        
        # Download Ducky
        ducky_zip = self.download_ducky()
        
        # Extract Ducky
        self.extract_ducky(ducky_zip)
        
        # Add to PATH
        self.add_to_path()
        
        print("\n" + "=" * 60)
        print("✓ Installation Complete!")
        print("=" * 60)
        print(f"\nPackScript and Ducky have been installed to:")
        print(f"  {self.install_dir}")
        print(f"\nYou can now use:")
        print(f"  pks <file.pks>          - Compile PackScript files")
        print(f"  ducky install <pkg>    - Install packages")
        print(f"  ducky list             - List installed packages")
        
        if sys.platform == 'win32':
            print(f"\nNote: Please restart your terminal or IDE for PATH changes to take effect")


def main():
    installer = PackScriptInstaller()
    installer.install()


if __name__ == "__main__":
    main()

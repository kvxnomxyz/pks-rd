# PackScript Language Documentation

## Table of Contents

1. [Syntax Overview](#syntax-overview)
2. [Data Types](#data-types)
3. [Variables](#variables)
4. [Operators](#operators)
5. [Control Flow](#control-flow)
6. [Functions & Subscripts](#functions--subscripts)
7. [Triggers](#triggers)
8. [Imports & Packages](#imports--packages)
9. [Built-in Functions](#built-in-functions)
10. [Best Practices](#best-practices)

## Syntax Overview

PackScript is a domain-specific language (DSL) designed for Minecraft modding. It has a distinctive syntax with named parameters and parenthesized blocks.

### Basic Structure

Every PackScript file has this structure:

```packscript
#init                          ~ Header section
modname(Name)
modver(1.0.0)
overridegamefiles(false)

preload(                       ~ Optional imports
    import from(package) get(function1, function2)
)

subscript.define(              ~ Optional subscript definitions
    name(myfunction)
    script(...)
)

trigger.add(                   ~ Optional trigger definitions
    name(mytrigger)
    subscript(myfunction)
)

#script                        ~ Main script section
log.print("Hello World")
```

## Data Types

PackScript supports several data types:

### Numbers
- Integers: `42`, `-5`, `0`
- Floats: `3.14`, `2.71`, `-0.5`

```packscript
setvar(health, 20)
setvar(damage, 5.5)
```

### Strings
- Double quotes: `"Hello World"`
- Single quotes: `'Hello World'`
- Escape sequences: `\n`, `\t`, `\"`, `\'`

```packscript
setvar(message, "Welcome to the server")
log.print("Health: 20\nMana: 100")
```

### Booleans
- `true` and `false`

```packscript
if(true) {
    log.print("This executes")
}
```

## Variables

Variables store data that can be used throughout your script.

### Creating Variables

Use `setvar()` to create and set variables:

```packscript
setvar(name, value)
```

Examples:
```packscript
setvar(count, 0)
setvar(player_name, "Steve")
setvar(is_admin, true)
```

### Using Variables

Retrieve variables with `getvar()`:

```packscript
getvar(variable_name)
```

Example:
```packscript
setvar(health, 20)
getvar(health)
log.print(health)  ~ Prints: 20
```

### Variable Scope

Variables are global within a script and persist across trigger events.

```packscript
setvar(counter, 0)

subscript.define(
    name(increment)
    script(
        setvar(counter, counter + 1)
    )
)
```

## Operators

### Arithmetic Operators

```packscript
setvar(x, 10 + 5)      ~ Addition: 15
setvar(y, 10 - 3)      ~ Subtraction: 7
setvar(z, 4 * 5)       ~ Multiplication: 20
setvar(a, 20 / 4)      ~ Division: 5
setvar(b, 17 % 5)      ~ Modulo: 2
```

### Comparison Operators

```packscript
10 == 10               ~ Equal: true
10 != 5                ~ Not equal: true
10 > 5                 ~ Greater than: true
5 < 10                 ~ Less than: true
10 >= 10               ~ Greater than or equal: true
5 <= 10                ~ Less than or equal: true
```

### Logical Operators

```packscript
true && true           ~ AND: true
true || false          ~ OR: true
!true                  ~ NOT: false
```

## Control Flow

### If Statements

Basic if statement:

```packscript
if(condition) {
    ~ Code runs if condition is true
}
```

With else:

```packscript
if(health < 5) {
    log.print("Low health!")
} else {
    log.print("Healthy")
}
```

With else if (nested):

```packscript
if(level > 100) {
    log.print("Master")
} else if(level > 50) {
    log.print("Expert")
} else {
    log.print("Novice")
}
```

### For Loops

Iterate a specific number of times:

```packscript
for i = 1 to 10 {
    log.print(i)
}
```

This prints numbers 1 through 9 (the "to" is exclusive).

### While Loops

Repeat while a condition is true:

```packscript
setvar(count, 0)
while(count < 5) {
    log.print(count)
    setvar(count, count + 1)
}
```

⚠️ **Warning**: Infinite loops will hang the game!

### Breaking Loops

There's no explicit break statement. Use conditions:

```packscript
for i = 0 to 100 {
    if(i == 50) {
        ~ Can't break directly, need to restructure
    }
}
```

## Functions & Subscripts

Subscripts are PackScript's way of defining functions.

### Defining a Subscript

```packscript
subscript.define(
    name(subscript_name)
    script(
        log.print("Subscript body")
    )
)
```

### Subscripts with Parameters

```packscript
subscript.define(
    name(greet)
    parameters(name)
    script(
        log.print("Hello ")
        log.print(name)
    )
)
```

### Calling Subscripts

Call via triggers:

```packscript
trigger.add(
    name(my_trigger)
    subscript(greet)
)

#script
run(trigger(my_trigger))
```

### Multiple Parameters

```packscript
subscript.define(
    name(add_numbers)
    parameters(a, b)
    script(
        setvar(result, a + b)
        log.print(result)
    )
)
```

## Triggers

Triggers connect subscripts to game events.

### Creating a Trigger

```packscript
trigger.add(
    name(event_name)
    subscript(subscript_name)
)
```

### Using Triggers

In your main script:

```packscript
run(trigger(event_name))
```

### Example

```packscript
subscript.define(
    name(on_player_join)
    parameters(player)
    script(
        log.print("Player joined!")
    )
)

trigger.add(
    name(player_join_event)
    subscript(on_player_join)
)

#script
run(trigger(player_join_event))
```

## Imports & Packages

### Importing from Packages

```packscript
preload(
    import from(package_name) get(function1, function2)
)
```

### Import All

```packscript
preload(
    import from(package_name) get(*)
)
```

### Using Imported Functions

```packscript
#init
modname(MyMod)
modver(1.0.0)
packages(easylog)

preload(
    import from(easylog) get(log_info, log_error)
)

#script

log_info("This is info")
log_error("This is an error")
```

## Built-in Functions

### Logging

```packscript
log.print(message)      ~ Print to console
chatlog(player)         ~ Log player chat
gamelog(message)        ~ Log game event
```

### Variables

```packscript
setvar(name, value)     ~ Set a variable
getvar(name)            ~ Get a variable
```

### Control

```packscript
return                  ~ Return from function
return(value)           ~ Return with value
```

## Best Practices

### 1. Always Include a Header

```packscript
#init
modname(MyMod)
modver(1.0.0)
overridegamefiles(false)
```

### 2. Use Comments

```packscript
~ This is a comment
~ Comments start with ~/ and go to end of line

setvar(count, 0)  ~ Inline comment
```

### 3. Organize Code

```packscript
~ Define imports first
preload(
    import from(package) get(*)
)

~ Define subscripts before triggers
subscript.define(...)
trigger.add(...)

#script
~ Main script last
```

### 4. Use Meaningful Names

```packscript
~ Good
setvar(player_health, 20)
subscript.define(name(on_player_death) ...)

~ Avoid
setvar(x, 20)
subscript.define(name(func1) ...)
```

### 5. Handle Errors

```packscript
if(getvar(my_var) == null) {
    log.print("Variable not initialized!")
}
```

### 6. Avoid Infinite Loops

```packscript
~ Bad - infinite loop!
while(true) {
    log.print("Oops!")
}

~ Good - finite loop
for i = 0 to 10 {
    log.print(i)
}
```

## Common Patterns

### Counter Pattern

```packscript
subscript.define(
    name(increment_counter)
    script(
        setvar(counter, counter + 1)
    )
)

#script
setvar(counter, 0)
trigger.add(name(on_event) subscript(increment_counter))
```

### Conditional Logging

```packscript
if(health < 10) {
    log.print("Warning: Low health!")
}
```

### String Building

```packscript
setvar(greeting, "Welcome, ")
setvar(name, "Steve")
~ Concatenation through multiple prints
log.print(greeting)
log.print(name)
```

---

For more examples, see the `examples/` directory.

# Ducky Package Manager - Documentation

## Overview

Ducky is the official package manager for PackScript. It downloads, installs, and manages PackScript packages from remote repositories.

## Installation

Ducky is included with the PackScript installer. To install it separately:

```bash
python installer/install.py
```

The installer will:
1. Download Ducky from the official repository
2. Extract it to your system
3. Add it to your PATH

## Quick Start

### Installing a Package

```bash
ducky install easylog
```

This downloads and installs the `easylog` package.

### Listing Packages

```bash
ducky list
```

Shows all installed packages:

```
Installed Packages:
------------------------------------------------------------
Name                 Version         Author
------------------------------------------------------------
easylog              1.0.0           PackScript Team
chat                 1.2.0           PackScript Team
player               1.1.0           PackScript Team
------------------------------------------------------------
Total: 3 package(s)
```

### Removing a Package

```bash
ducky uninstall easylog
```

### Package Information

```bash
ducky show easylog
```

Displays details about a package:

```
Package: easylog
Version: 1.0.0
Author: PackScript Team
Description: Easy logging utilities for PackScript
Installed at: 2024-01-15T10:30:00
Files: 3 file(s)
```

### Searching Packages

```bash
ducky search logging
```

Finds packages matching the search term.

### Repository Information

```bash
ducky info
```

Shows all available packages in the repository.

## Package Structure

A PackScript package is a ZIP file (`.ppkg`) with the following structure:

```
mypackage.ppkg
├── package.json          ~ Package metadata
├── mypackage.pks         ~ Main package code
└── utilities.pks         ~ Additional files
```

### package.json Format

```json
{
  "name": "mypackage",
  "version": "1.0.0",
  "author": "Your Name",
  "description": "A description of what your package does",
  "dependencies": ["other-package"],
  "files": ["mypackage.pks", "utilities.pks"]
}
```

**Fields:**
- `name`: Package identifier (lowercase, no spaces)
- `version`: Semantic version (major.minor.patch)
- `author`: Package author name
- `description`: Brief package description
- `dependencies`: Array of package dependencies
- `files`: Array of included files

## Creating a Package

### Step 1: Create Package Directory

```bash
mkdir mypackage
cd mypackage
```

### Step 2: Create package.json

```json
{
  "name": "mypackage",
  "version": "1.0.0",
  "author": "Your Name",
  "description": "My awesome PackScript utilities",
  "dependencies": [],
  "files": ["mypackage.pks"]
}
```

### Step 3: Add PackScript Files

Create `mypackage.pks`:

```packscript
subscript.define(
    name(my_function)
    parameters(arg)
    script(
        log.print("Argument: ")
        log.print(arg)
    )
)

subscript.define(
    name(another_function)
    script(
        log.print("Hello from my package!")
    )
)
```

### Step 4: Package it

```bash
python packages/packager.py packages/mypackage
```

This creates `mypackage-1.0.0.ppkg`.

### Step 5: Upload to Repository

Upload your `.ppkg` file to your hosting (GitHub, etc.) and register it in the repository index.

## Repository Configuration

### Repository Index Format

The repository index is a JSON file listing all available packages:

```json
{
  "easylog": {
    "name": "easylog",
    "version": "1.0.0",
    "author": "PackScript Team",
    "description": "Easy logging utilities",
    "url": "https://example.com/packages/easylog.ppkg",
    "dependencies": [],
    "versions": {
      "1.0.0": {
        "url": "https://example.com/packages/easylog-1.0.0.ppkg",
        "checksum": "abc123..."
      }
    }
  }
}
```

### Default Repository

The default repository is:
```
https://raw.githubusercontent.com/kvxnomxyz/pks-rd/package-repositories.json
```

### Using a Custom Repository

Set the `DUCKY_REPO` environment variable:

```bash
# Windows
set DUCKY_REPO=https://your-repository.com/packages.json

# Linux/Mac
export DUCKY_REPO=https://your-repository.com/packages.json
```

## Using Packages

### In Your PackScript Files

```packscript
#init
modname(MyMod)
modver(1.0.0)
overridegamefiles(false)
packages(mypackage)

preload(
    import from(mypackage) get(my_function, another_function)
)

#script

my_function("test")
another_function()
```

## Package Registry

Packages are stored in `~/.ducky/packages/`:

```
~/.ducky/
├── packages/
│   ├── registry.json              ~ Package registry
│   ├── easylog/
│   │   ├── package.json
│   │   ├── easylog.pks
│   │   └── ...
│   ├── chat/
│   │   ├── package.json
│   │   ├── chat.pks
│   │   └── ...
│   └── ...
└── cache/                         ~ Downloaded packages
```

## Commands Reference

```bash
~ Install a package
ducky install <package>

~ Uninstall a package
ducky uninstall <package>

~ List installed packages
ducky list

~ Show package info
ducky show <package>

~ Search for packages
ducky search <query>

~ Show repository info
ducky info
```

## Troubleshooting

### Package Not Found

```
Error: Package 'mypackage' not found in repository
```

Common causes:
- Typo in package name
- Package not uploaded to repository
- Repository index not updated

### Download Failed

```
Error: Failed to download mypackage: Connection refused
```

Check:
- Internet connection
- Repository URL is correct
- Package URL is accessible

### Installation Conflicts

If a package conflicts with an existing one:

```bash
ducky uninstall conflicting-package
ducky install new-package
```

## Best Practices

### 1. Use Semantic Versioning

```
1.0.0  ~ major.minor.patch
```

- **Major**: Breaking changes
- **Minor**: New features (backward compatible)
- **Patch**: Bug fixes

### 2. Manage Dependencies

```json
{
  "dependencies": ["easylog", "chat"]
}
```

Keep dependencies minimal.

### 3. Test Before Publishing

Install locally and test:

```bash
ducky install ./mypackage.ppkg
```

### 4. Document Your Package

Include a README with:
- What the package does
- How to use it
- Examples
- Dependencies

### 5. Use Namespacing

Avoid naming conflicts:

```packscript
subscript.define(
    name(mypackage_function)
    script(...)
)
```

## Advanced Usage

### Installing from File

```bash
ducky install ./path/to/package.ppkg
```

### Viewing Package Contents

```bash
unzip -l ~/.ducky/packages/easylog/easylog.ppkg
```

### Clearing Cache

```bash
rm -rf ~/.ducky/cache/*
```

## Package Examples

### easylog v1.0.0

Logging utilities with different log levels.

Usage:
```packscript
#init
packages(easylog)
preload(
    import from(easylog) get(log_info, log_error)
)

#script
log_info("This is information")
log_error("This is an error")
```

### chat v1.2.0

Chat and messaging system for players.

Usage:
```packscript
#init
packages(chat)
preload(
    import from(chat) get(send_player_message)
)

#script
send_player_message("player_name", "Hello!")
```

### player v1.1.0

Player management utilities.

Usage:
```packscript
#init
packages(player)
preload(
    import from(player) get(set_health, add_item)
)

#script
set_health("Steve", 20)
add_item("Steve", "diamond", 64)
```

## Contributing Packages

To contribute a package:

1. Create and test your package
2. Upload to a public repository (GitHub, etc.)
3. Create a PR to add it to the official registry
4. Include documentation and examples

---

For more information, see the main [README.md](README.md) and [LANGUAGE.md](LANGUAGE.md).

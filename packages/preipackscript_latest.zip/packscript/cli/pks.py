"""
PackScript CLI Tool
"""
import sys
import argparse
import os
from pathlib import Path
from ..compiler.compiler import compile_packscript

def main():
    parser = argparse.ArgumentParser(
        description="PackScript Compiler - Compile PackScript to Java"
    )
    
    parser.add_argument(
        "source",
        help="Source .pks file to compile"
    )
    
    parser.add_argument(
        "-o", "--output",
        help="Output Java file (default: same name as source with .java extension)",
        default=None
    )
    
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    
    args = parser.parse_args()
    
    # Verify source file exists
    if not os.path.exists(args.source):
        print(f"Error: Source file '{args.source}' not found")
        sys.exit(1)
    
    try:
        if args.verbose:
            print(f"Compiling {args.source}...")
        
        output_file = compile_packscript(args.source, args.output)
        
        if args.verbose:
            print(f"✓ Successfully compiled to {output_file}")
        else:
            print(f"✓ Compiled to {output_file}")
        
    except Exception as e:
        print(f"Error: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()

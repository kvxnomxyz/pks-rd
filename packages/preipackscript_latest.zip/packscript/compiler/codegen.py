"""
PackScript Code Generator - Converts AST to Java code
"""
from typing import List, Dict, Any
from .ast_nodes import *

class JavaCodeGenerator:
    def __init__(self):
        self.indent_level = 0
        self.code_lines: List[str] = []
        self.variables: Dict[str, str] = {}
        self.subscripts: Dict[str, Dict] = {}
        self.triggers: List[Dict] = []
    
    def indent(self):
        """Increase indentation level"""
        self.indent_level += 1
    
    def dedent(self):
        """Decrease indentation level"""
        self.indent_level = max(0, self.indent_level - 1)
    
    def emit(self, code: str):
        """Emit a line of code"""
        if code.strip():
            self.code_lines.append("    " * self.indent_level + code)
        else:
            self.code_lines.append("")
    
    def generate(self, program: Program) -> str:
        """Generate Java code from AST"""
        self.emit("// PackScript Generated Java Code")
        self.emit(f"// Mod: {program.header.modname} v{program.header.modver}")
        self.emit("")
        self.emit("import net.minecraftforge.api.distmarker.Dist;")
        self.emit("import net.minecraftforge.api.distmarker.OnlyIn;")
        self.emit("import net.minecraftforge.client.event.ScreenEvent;")
        self.emit("import net.minecraftforge.common.MinecraftForge;")
        self.emit("import net.minecraftforge.event.server.ServerStartingEvent;")
        self.emit("import net.minecraftforge.eventbus.api.SubscribeEvent;")
        self.emit("import net.minecraftforge.fml.common.Mod;")
        self.emit("import net.minecraft.client.Minecraft;")
        self.emit("import java.util.*;")
        self.emit("")
        
        class_name = self._sanitize_name(program.header.modname)
        self.emit(f"@Mod.EventBusSubscriber(modid = \"{class_name}\", bus = Mod.EventBusSubscriber.Bus.FORGE)")
        self.emit(f"public class {class_name}Handler {{")
        self.indent()
        
        # Class-level variables
        self.emit("private static Map<String, Object> variables = new HashMap<>();")
        self.emit("private static Map<String, Runnable> triggers = new HashMap<>();")
        self.emit("")
        
        # Generate subscripts as methods
        for subscript in program.subscripts:
            self.generate_subscript(subscript, class_name)
        
        # Register triggers
        if program.triggers:
            self.emit("static {")
            self.indent()
            for trigger in program.triggers:
                self.generate_trigger_registration(trigger)
            self.dedent()
            self.emit("}")
            self.emit("")
        
        # Generate script execution
        self.emit("@SubscribeEvent")
        self.emit("public static void onServerStart(ServerStartingEvent event) {")
        self.indent()
        self.emit("// Execute main script")
        for stmt in program.script.statements:
            self.generate_statement(stmt)
        self.dedent()
        self.emit("}")
        
        self.dedent()
        self.emit("}")
        
        return "\n".join(self.code_lines)
    
    def _sanitize_name(self, name: str) -> str:
        """Sanitize a name for Java"""
        return ''.join(c if c.isalnum() or c == '_' else '_' for c in name)
    
    def generate_subscript(self, subscript: SubscriptDef, class_name: str):
        """Generate a method for a subscript"""
        method_name = self._sanitize_name(subscript.name)
        params = ", ".join(f"Object {p}" for p in subscript.parameters) if subscript.parameters else ""
        
        self.emit(f"public static void {method_name}({params}) {{")
        self.indent()
        
        for stmt in subscript.body:
            self.generate_statement(stmt)
        
        self.dedent()
        self.emit("}")
        self.emit("")
    
    def generate_trigger_registration(self, trigger: TriggerDef):
        """Generate trigger registration code"""
        subscript_name = self._sanitize_name(trigger.subscript_name)
        trigger_name = self._sanitize_name(trigger.name)
        self.emit(f"triggers.put(\"{trigger_name}\", {subscript_name}::run);")
    
    def generate_statement(self, stmt: Statement):
        """Generate code for a statement"""
        if isinstance(stmt, FunctionCall):
            self.generate_function_call(stmt)
        elif isinstance(stmt, Assignment):
            self.generate_assignment(stmt)
        elif isinstance(stmt, IfStatement):
            self.generate_if_statement(stmt)
        elif isinstance(stmt, WhileStatement):
            self.generate_while_statement(stmt)
        elif isinstance(stmt, ForStatement):
            self.generate_for_statement(stmt)
        elif isinstance(stmt, RunStatement):
            self.generate_run_statement(stmt)
        elif isinstance(stmt, ReturnStatement):
            self.generate_return_statement(stmt)
        elif isinstance(stmt, Expression):
            # Expression statement
            expr_code = self.generate_expression(stmt)
            if expr_code:
                self.emit(expr_code + ";")
    
    def generate_function_call(self, call: FunctionCall):
        """Generate code for a function call"""
        if call.name == "log.print":
            args = ", ".join(self.generate_expression(arg) for arg in call.arguments)
            self.emit(f"System.out.println({args});")
        else:
            method_name = self._sanitize_name(call.name)
            args = ", ".join(self.generate_expression(arg) for arg in call.arguments)
            self.emit(f"{method_name}({args});")
    
    def generate_assignment(self, assign: Assignment):
        """Generate code for assignment"""
        var_name = assign.var_name
        value = self.generate_expression(assign.value)
        self.emit(f"variables.put(\"{var_name}\", {value});")
        self.variables[var_name] = "Object"
    
    def generate_if_statement(self, if_stmt: IfStatement):
        """Generate code for if statement"""
        condition = self.generate_expression(if_stmt.condition)
        self.emit(f"if ({condition}) {{")
        self.indent()
        
        for stmt in if_stmt.then_block:
            self.generate_statement(stmt)
        
        self.dedent()
        
        if if_stmt.else_block:
            self.emit("} else {")
            self.indent()
            
            for stmt in if_stmt.else_block:
                self.generate_statement(stmt)
            
            self.dedent()
            self.emit("}")
        else:
            self.emit("}")
    
    def generate_while_statement(self, while_stmt: WhileStatement):
        """Generate code for while statement"""
        condition = self.generate_expression(while_stmt.condition)
        self.emit(f"while ({condition}) {{")
        self.indent()
        
        for stmt in while_stmt.body:
            self.generate_statement(stmt)
        
        self.dedent()
        self.emit("}")
    
    def generate_for_statement(self, for_stmt: ForStatement):
        """Generate code for for statement"""
        start = self.generate_expression(for_stmt.start)
        end = self.generate_expression(for_stmt.end)
        var_name = for_stmt.var_name
        
        self.emit(f"for (int {var_name} = {start}; {var_name} < {end}; {var_name}++) {{")
        self.indent()
        
        for stmt in for_stmt.body:
            self.generate_statement(stmt)
        
        self.dedent()
        self.emit("}")
    
    def generate_run_statement(self, run_stmt: RunStatement):
        """Generate code for run statement"""
        target = self.generate_expression(run_stmt.target)
        self.emit(f"if (triggers.containsKey({target})) triggers.get({target}).run();")
    
    def generate_return_statement(self, ret_stmt: ReturnStatement):
        """Generate code for return statement"""
        if ret_stmt.value:
            value = self.generate_expression(ret_stmt.value)
            self.emit(f"return {value};")
        else:
            self.emit("return;")
    
    def generate_expression(self, expr: Expression) -> str:
        """Generate code for an expression"""
        if isinstance(expr, BinaryOp):
            left = self.generate_expression(expr.left)
            right = self.generate_expression(expr.right)
            return f"({left} {expr.op} {right})"
        
        elif isinstance(expr, UnaryOp):
            operand = self.generate_expression(expr.operand)
            return f"({expr.op}{operand})"
        
        elif isinstance(expr, Literal):
            if expr.type == 'string':
                return f'\"{expr.value}\"'
            elif expr.type == 'boolean':
                return 'true' if expr.value else 'false'
            else:
                return str(expr.value)
        
        elif isinstance(expr, Variable):
            # Get variable from map
            return f"variables.get(\"{expr.name}\")"
        
        elif isinstance(expr, MethodCall):
            args = ", ".join(self.generate_expression(arg) for arg in expr.arguments)
            if expr.name == "print":
                return f"System.out.println({args})"
            else:
                method_name = self._sanitize_name(expr.name)
                return f"{method_name}({args})"
        
        elif isinstance(expr, FunctionCall):
            args = ", ".join(self.generate_expression(arg) for arg in expr.arguments)
            if expr.name == "log.print":
                return f"System.out.println({args})"
            else:
                method_name = self._sanitize_name(expr.name)
                return f"{method_name}({args})"
        
        return ""

"""
PackScript Parser - Parses tokens into an Abstract Syntax Tree
"""
from typing import List, Optional
from .lexer import Token, TokenType, Lexer
from .ast_nodes import *

class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.position = 0
        self.current_token = self.tokens[0] if tokens else None
    
    def advance(self):
        """Move to the next token"""
        self.position += 1
        if self.position < len(self.tokens):
            self.current_token = self.tokens[self.position]
        else:
            self.current_token = None
    
    def peek(self, offset: int = 1) -> Optional[Token]:
        """Look ahead at the next token"""
        peek_pos = self.position + offset
        if peek_pos < len(self.tokens):
            return self.tokens[peek_pos]
        return None
    
    def skip_newlines(self):
        """Skip any newline tokens"""
        while self.current_token and self.current_token.type == TokenType.NEWLINE:
            self.advance()
    
    def expect(self, token_type: TokenType) -> Token:
        """Expect a specific token type and advance"""
        if not self.current_token or self.current_token.type != token_type:
            raise SyntaxError(f"Expected {token_type}, got {self.current_token}")
        token = self.current_token
        self.advance()
        return token
    
    def match(self, *token_types: TokenType) -> bool:
        """Check if current token matches any of the given types"""
        if not self.current_token:
            return False
        return self.current_token.type in token_types
    
    def parse(self) -> Program:
        """Parse the entire program"""
        self.skip_newlines()
        
        # Parse header
        header = self.parse_header()
        
        self.skip_newlines()
        
        # Parse imports
        imports = []
        while self.match(TokenType.IMPORT):
            imports.append(self.parse_import())
            self.skip_newlines()
        
        # Parse subscripts and triggers (before script)
        subscripts = []
        triggers = []
        while self.match(TokenType.SUBSCRIPT, TokenType.TRIGGER):
            if self.match(TokenType.SUBSCRIPT):
                subscripts.append(self.parse_subscript())
            else:
                triggers.append(self.parse_trigger())
            self.skip_newlines()
        
        # Parse script section
        script = self.parse_script()
        
        return Program(header, imports, subscripts, triggers, script)
    
    def parse_header(self) -> Header:
        """Parse the #init header"""
        self.expect(TokenType.INIT)
        self.skip_newlines()
        
        modname = ""
        modver = ""
        override = False
        packages = []
        
        while not self.match(TokenType.SCRIPT, TokenType.SUBSCRIPT, TokenType.TRIGGER, TokenType.IMPORT, TokenType.EOF):
            if self.match(TokenType.IDENTIFIER):
                if self.current_token.value == "modname":
                    self.advance()
                    self.expect(TokenType.LPAREN)
                    modname = self.expect(TokenType.IDENTIFIER).value
                    self.expect(TokenType.RPAREN)
                
                elif self.current_token.value == "modver":
                    self.advance()
                    self.expect(TokenType.LPAREN)
                    modver_token = self.current_token
                    if self.match(TokenType.STRING, TokenType.NUMBER, TokenType.IDENTIFIER):
                        modver = self.current_token.value
                        self.advance()
                    self.expect(TokenType.RPAREN)
                
                elif self.current_token.value == "overridegamefiles":
                    self.advance()
                    self.expect(TokenType.LPAREN)
                    val = self.expect(TokenType.IDENTIFIER).value.lower()
                    override = val == "true"
                    self.expect(TokenType.RPAREN)
                
                elif self.current_token.value == "packages":
                    self.advance()
                    self.expect(TokenType.LPAREN)
                    while not self.match(TokenType.RPAREN):
                        pkg = self.expect(TokenType.IDENTIFIER).value
                        packages.append(pkg)
                        if self.match(TokenType.COMMA):
                            self.advance()
                    self.expect(TokenType.RPAREN)
                else:
                    self.advance()
            else:
                self.advance()
            
            self.skip_newlines()
        
        return Header(modname, modver, override, packages)
    
    def parse_import(self) -> ImportStatement:
        """Parse an import statement"""
        self.expect(TokenType.IMPORT)
        self.expect(TokenType.FROM)
        package = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.GET)
        
        items = []
        if self.match(TokenType.STAR):
            items = ["*"]
            self.advance()
        else:
            while True:
                items.append(self.expect(TokenType.IDENTIFIER).value)
                if self.match(TokenType.COMMA):
                    self.advance()
                else:
                    break
        
        return ImportStatement(package, items)
    
    def parse_subscript(self) -> SubscriptDef:
        """Parse a subscript definition"""
        self.expect(TokenType.SUBSCRIPT)
        self.expect(TokenType.DOT)
        self.expect(TokenType.IDENTIFIER)  # 'define'
        self.expect(TokenType.LPAREN)
        
        self.skip_newlines()
        self.expect(TokenType.IDENTIFIER)  # 'name'
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        
        self.skip_newlines()
        
        # Parse parameters if they exist
        parameters = []
        if self.match(TokenType.IDENTIFIER) and self.current_token.value == "parameters":
            self.advance()
            self.expect(TokenType.LPAREN)
            while not self.match(TokenType.RPAREN):
                parameters.append(self.expect(TokenType.IDENTIFIER).value)
                if self.match(TokenType.COMMA):
                    self.advance()
            self.expect(TokenType.RPAREN)
            self.skip_newlines()
        
        self.expect(TokenType.IDENTIFIER)  # 'script'
        self.expect(TokenType.LPAREN)
        
        body = self.parse_statement_list()
        
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.RPAREN)
        
        return SubscriptDef(name, parameters, body)
    
    def parse_trigger(self) -> TriggerDef:
        """Parse a trigger definition"""
        self.expect(TokenType.TRIGGER)
        self.expect(TokenType.DOT)
        self.expect(TokenType.IDENTIFIER)  # 'add'
        self.expect(TokenType.LPAREN)
        
        self.skip_newlines()
        self.expect(TokenType.IDENTIFIER)  # 'name'
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        
        self.skip_newlines()
        self.expect(TokenType.IDENTIFIER)  # 'subscript'
        self.expect(TokenType.LPAREN)
        subscript_name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        
        self.skip_newlines()
        self.expect(TokenType.RPAREN)
        
        return TriggerDef(name, subscript_name)
    
    def parse_script(self) -> ScriptBlock:
        """Parse the #script section"""
        self.expect(TokenType.SCRIPT)
        self.skip_newlines()
        
        statements = self.parse_statement_list()
        return ScriptBlock(statements)
    
    def parse_statement_list(self) -> List[Statement]:
        """Parse a list of statements"""
        statements = []
        
        while not self.match(TokenType.RPAREN, TokenType.RBRACE, TokenType.EOF):
            self.skip_newlines()
            
            if self.match(TokenType.RPAREN, TokenType.RBRACE, TokenType.EOF):
                break
            
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            
            self.skip_newlines()
        
        return statements
    
    def parse_statement(self) -> Optional[Statement]:
        """Parse a single statement"""
        self.skip_newlines()
        
        if not self.current_token or self.match(TokenType.RPAREN, TokenType.RBRACE, TokenType.EOF):
            return None
        
        # If statement
        if self.match(TokenType.IF):
            return self.parse_if_statement()
        
        # While loop
        if self.match(TokenType.WHILE):
            return self.parse_while_statement()
        
        # For loop
        if self.match(TokenType.FOR):
            return self.parse_for_statement()
        
        # Return statement
        if self.match(TokenType.RETURN):
            self.advance()
            expr = None
            if not self.match(TokenType.RPAREN, TokenType.RBRACE, TokenType.NEWLINE, TokenType.SEMICOLON):
                expr = self.parse_expression()
            if self.match(TokenType.SEMICOLON):
                self.advance()
            return ReturnStatement(expr)
        
        # Run statement
        if self.match(TokenType.RUN):
            return self.parse_run_statement()
        
        # Try to parse as expression statement or assignment
        expr = self.parse_expression()
        
        if self.match(TokenType.SEMICOLON):
            self.advance()
        
        return expr
    
    def parse_if_statement(self) -> IfStatement:
        """Parse an if statement"""
        self.expect(TokenType.IF)
        self.expect(TokenType.LPAREN)
        condition = self.parse_expression()
        self.expect(TokenType.RPAREN)
        
        self.skip_newlines()
        
        then_block = []
        if self.match(TokenType.LBRACE):
            self.advance()
            then_block = self.parse_statement_list()
            self.expect(TokenType.RBRACE)
        else:
            then_block = [self.parse_statement()]
        
        else_block = None
        if self.match(TokenType.ELSE):
            self.advance()
            self.skip_newlines()
            if self.match(TokenType.LBRACE):
                self.advance()
                else_block = self.parse_statement_list()
                self.expect(TokenType.RBRACE)
            else:
                else_block = [self.parse_statement()]
        
        return IfStatement(condition, then_block, else_block)
    
    def parse_while_statement(self) -> WhileStatement:
        """Parse a while loop"""
        self.expect(TokenType.WHILE)
        self.expect(TokenType.LPAREN)
        condition = self.parse_expression()
        self.expect(TokenType.RPAREN)
        
        self.skip_newlines()
        
        body = []
        if self.match(TokenType.LBRACE):
            self.advance()
            body = self.parse_statement_list()
            self.expect(TokenType.RBRACE)
        else:
            body = [self.parse_statement()]
        
        return WhileStatement(condition, body)
    
    def parse_for_statement(self) -> ForStatement:
        """Parse a for loop"""
        self.expect(TokenType.FOR)
        var_name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.EQUALS)
        start = self.parse_expression()
        self.expect(TokenType.IDENTIFIER)  # to
        end = self.parse_expression()
        
        self.skip_newlines()
        
        body = []
        if self.match(TokenType.LBRACE):
            self.advance()
            body = self.parse_statement_list()
            self.expect(TokenType.RBRACE)
        else:
            body = [self.parse_statement()]
        
        return ForStatement(var_name, start, end, body)
    
    def parse_run_statement(self) -> RunStatement:
        """Parse a run statement"""
        self.expect(TokenType.RUN)
        self.expect(TokenType.LPAREN)
        target = self.parse_expression()
        self.expect(TokenType.RPAREN)
        return RunStatement(target)
    
    def parse_expression(self) -> Expression:
        """Parse an expression"""
        return self.parse_or_expression()
    
    def parse_or_expression(self) -> Expression:
        """Parse logical OR expression"""
        left = self.parse_and_expression()
        
        while self.match(TokenType.OR):
            op = self.current_token.value
            self.advance()
            right = self.parse_and_expression()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_and_expression(self) -> Expression:
        """Parse logical AND expression"""
        left = self.parse_equality_expression()
        
        while self.match(TokenType.AND):
            op = self.current_token.value
            self.advance()
            right = self.parse_equality_expression()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_equality_expression(self) -> Expression:
        """Parse equality expression"""
        left = self.parse_relational_expression()
        
        while self.match(TokenType.EQ, TokenType.NE):
            op = self.current_token.value
            self.advance()
            right = self.parse_relational_expression()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_relational_expression(self) -> Expression:
        """Parse relational expression"""
        left = self.parse_additive_expression()
        
        while self.match(TokenType.LT, TokenType.GT, TokenType.LE, TokenType.GE):
            op = self.current_token.value
            self.advance()
            right = self.parse_additive_expression()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_additive_expression(self) -> Expression:
        """Parse addition and subtraction"""
        left = self.parse_multiplicative_expression()
        
        while self.match(TokenType.PLUS, TokenType.MINUS):
            op = self.current_token.value
            self.advance()
            right = self.parse_multiplicative_expression()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_multiplicative_expression(self) -> Expression:
        """Parse multiplication, division, and modulo"""
        left = self.parse_unary_expression()
        
        while self.match(TokenType.STAR, TokenType.SLASH, TokenType.PERCENT):
            op = self.current_token.value
            self.advance()
            right = self.parse_unary_expression()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_unary_expression(self) -> Expression:
        """Parse unary expressions"""
        if self.match(TokenType.NOT, TokenType.MINUS):
            op = self.current_token.value
            self.advance()
            operand = self.parse_unary_expression()
            return UnaryOp(op, operand)
        
        return self.parse_postfix_expression()
    
    def parse_postfix_expression(self) -> Expression:
        """Parse postfix expressions (method calls, indexing)"""
        expr = self.parse_primary_expression()
        
        while True:
            if self.match(TokenType.DOT):
                self.advance()
                name = self.expect(TokenType.IDENTIFIER).value
                
                if self.match(TokenType.LPAREN):
                    # Method call
                    self.advance()
                    args = self.parse_argument_list()
                    self.expect(TokenType.RPAREN)
                    expr = MethodCall(name, args)
                else:
                    # Property access
                    expr = Variable(str(expr))
            elif self.match(TokenType.LPAREN) and isinstance(expr, Variable):
                # Function call on variable
                self.advance()
                args = self.parse_argument_list()
                self.expect(TokenType.RPAREN)
                expr = MethodCall(expr.name, args)
            else:
                break
        
        return expr
    
    def parse_primary_expression(self) -> Expression:
        """Parse primary expressions"""
        self.skip_newlines()
        
        # Parenthesized expression
        if self.match(TokenType.LPAREN):
            self.advance()
            expr = self.parse_expression()
            self.expect(TokenType.RPAREN)
            return expr
        
        # Number literal
        if self.match(TokenType.NUMBER):
            value = self.current_token.value
            self.advance()
            if '.' in value:
                return Literal(float(value), 'number')
            return Literal(int(value), 'number')
        
        # String literal
        if self.match(TokenType.STRING):
            value = self.current_token.value
            self.advance()
            return Literal(value, 'string')
        
        # Boolean literals
        if self.match(TokenType.IDENTIFIER):
            if self.current_token.value in ('true', 'false'):
                value = self.current_token.value == 'true'
                self.advance()
                return Literal(value, 'boolean')
        
        # Function call
        if self.match(TokenType.LOG_PRINT):
            self.advance()
            self.expect(TokenType.LPAREN)
            args = self.parse_argument_list()
            self.expect(TokenType.RPAREN)
            return FunctionCall('log.print', args)
        
        if self.match(TokenType.SET_VAR):
            self.advance()
            self.expect(TokenType.LPAREN)
            var_name = self.expect(TokenType.IDENTIFIER).value
            self.expect(TokenType.COMMA)
            value = self.parse_expression()
            self.expect(TokenType.RPAREN)
            return Assignment(var_name, value)
        
        if self.match(TokenType.GET_VAR):
            self.advance()
            self.expect(TokenType.LPAREN)
            var_name = self.expect(TokenType.IDENTIFIER).value
            self.expect(TokenType.RPAREN)
            return Variable(var_name)
        
        # Variable reference or function call
        if self.match(TokenType.IDENTIFIER):
            name = self.current_token.value
            self.advance()
            
            # Check if it's an assignment
            if self.match(TokenType.EQUALS):
                self.advance()
                value = self.parse_expression()
                return Assignment(name, value)
            
            # Check if it's a function call
            if self.match(TokenType.LPAREN):
                self.advance()
                args = self.parse_argument_list()
                self.expect(TokenType.RPAREN)
                return FunctionCall(name, args)
            
            return Variable(name)
        
        raise SyntaxError(f"Unexpected token: {self.current_token}")
    
    def parse_argument_list(self) -> List[Expression]:
        """Parse function arguments"""
        args = []
        
        while not self.match(TokenType.RPAREN):
            args.append(self.parse_expression())
            if self.match(TokenType.COMMA):
                self.advance()
            else:
                break
        
        return args


def parse(source: str) -> Program:
    """Parse PackScript source code"""
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    return parser.parse()

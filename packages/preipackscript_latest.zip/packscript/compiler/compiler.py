"""
PackScript Main Compiler
"""
import os
import sys
from pathlib import Path
from .lexer import Lexer
from .parser import Parser
from .codegen import JavaCodeGenerator

class PackScriptCompiler:
    def __init__(self, source_file: str):
        self.source_file = source_file
        self.source = None
        self.output_file = None
    
    def read_source(self):
        """Read the source file"""
        try:
            with open(self.source_file, 'r', encoding='utf-8') as f:
                self.source = f.read()
        except FileNotFoundError:
            raise FileNotFoundError(f"Source file not found: {self.source_file}")
    
    def compile(self) -> str:
        """Compile PackScript to Java"""
        self.read_source()
        
        # Tokenize
        lexer = Lexer(self.source)
        tokens = lexer.tokenize()
        
        # Parse
        parser = Parser(tokens)
        ast = parser.parse()
        
        # Generate code
        generator = JavaCodeGenerator()
        java_code = generator.generate(ast)
        
        return java_code
    
    def compile_to_file(self, output_file: str = None) -> str:
        """Compile and write to file"""
        if output_file is None:
            base = Path(self.source_file).stem
            output_file = base + ".java"
        
        java_code = self.compile()
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(java_code)
        
        return output_file


def compile_packscript(source_file: str, output_file: str = None) -> str:
    """Compile a PackScript file to Java"""
    compiler = PackScriptCompiler(source_file)
    return compiler.compile_to_file(output_file)

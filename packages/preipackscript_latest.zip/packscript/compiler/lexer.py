"""
PackScript Lexer - Tokenizes PackScript source code
"""
import re
from enum import Enum
from dataclasses import dataclass
from typing import List, Optional

class TokenType(Enum):
    # Literals and Identifiers
    IDENTIFIER = "IDENTIFIER"
    NUMBER = "NUMBER"
    STRING = "STRING"
    
    # Keywords
    INIT = "#init"
    SCRIPT = "#script"
    SUBSCRIPT = "subscript"
    TRIGGER = "trigger"
    RUN = "run"
    IMPORT = "import"
    FROM = "from"
    GET = "get"
    
    # Built-in functions
    LOG_PRINT = "log.print"
    CHAT_LOG = "chatlog"
    GAME_LOG = "gamelog"
    SET_VAR = "setvar"
    GET_VAR = "getvar"
    IF = "if"
    ELSE = "else"
    WHILE = "while"
    FOR = "for"
    RETURN = "return"
    FUNCTION_DEF = "func"
    
    # Operators and Delimiters
    LPAREN = "("
    RPAREN = ")"
    LBRACE = "{"
    RBRACE = "}"
    LBRACKET = "["
    RBRACKET = "]"
    COMMA = ","
    DOT = "."
    COLON = ":"
    SEMICOLON = ";"
    EQUALS = "="
    PLUS = "+"
    MINUS = "-"
    STAR = "*"
    SLASH = "/"
    PERCENT = "%"
    EQ = "=="
    NE = "!="
    LT = "<"
    GT = ">"
    LE = "<="
    GE = ">="
    AND = "&&"
    OR = "||"
    NOT = "!"
    
    # Special
    COMMENT = "COMMENT"
    NEWLINE = "NEWLINE"
    EOF = "EOF"

@dataclass
class Token:
    type: TokenType
    value: str
    line: int
    column: int

class Lexer:
    def __init__(self, source: str):
        self.source = source
        self.position = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.current_char = self.source[0] if source else None
    
    def advance(self):
        """Move to the next character"""
        if self.current_char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        
        self.position += 1
        if self.position < len(self.source):
            self.current_char = self.source[self.position]
        else:
            self.current_char = None
    
    def peek(self, offset: int = 1) -> Optional[str]:
        """Look ahead at the next character"""
        peek_pos = self.position + offset
        if peek_pos < len(self.source):
            return self.source[peek_pos]
        return None
    
    def skip_whitespace(self):
        """Skip whitespace except newlines"""
        while self.current_char and self.current_char in ' \t\r':
            self.advance()
    
    def skip_comment(self):
        """Skip comments (~/ ... )"""
        if self.current_char == '~':
            while self.current_char and self.current_char != '\n':
                self.advance()
    
    def read_string(self, quote_char: str) -> str:
        """Read a string literal"""
        result = ''
        self.advance()  # Skip opening quote
        
        while self.current_char and self.current_char != quote_char:
            if self.current_char == '\\':
                self.advance()
                if self.current_char == 'n':
                    result += '\n'
                elif self.current_char == 't':
                    result += '\t'
                elif self.current_char == '"':
                    result += '"'
                elif self.current_char == "'":
                    result += "'"
                else:
                    result += self.current_char
                self.advance()
            else:
                result += self.current_char
                self.advance()
        
        if self.current_char == quote_char:
            self.advance()  # Skip closing quote
        
        return result
    
    def read_number(self) -> str:
        """Read a number (integer or float)"""
        result = ''
        while self.current_char and (self.current_char.isdigit() or self.current_char == '.'):
            result += self.current_char
            self.advance()
        return result
    
    def read_identifier(self) -> str:
        """Read an identifier or keyword"""
        result = ''
        while self.current_char and (self.current_char.isalnum() or self.current_char in '_.-#'):
            result += self.current_char
            self.advance()
        return result
    
    def get_token_type(self, text: str) -> TokenType:
        """Determine token type for a given text"""
        keywords = {
            '#init': TokenType.INIT,
            '#script': TokenType.SCRIPT,
            'subscript': TokenType.SUBSCRIPT,
            'trigger': TokenType.TRIGGER,
            'run': TokenType.RUN,
            'import': TokenType.IMPORT,
            'from': TokenType.FROM,
            'get': TokenType.GET,
            'log.print': TokenType.LOG_PRINT,
            'chatlog': TokenType.CHAT_LOG,
            'gamelog': TokenType.GAME_LOG,
            'setvar': TokenType.SET_VAR,
            'getvar': TokenType.GET_VAR,
            'if': TokenType.IF,
            'else': TokenType.ELSE,
            'while': TokenType.WHILE,
            'for': TokenType.FOR,
            'return': TokenType.RETURN,
            'func': TokenType.FUNCTION_DEF,
        }
        return keywords.get(text, TokenType.IDENTIFIER)
    
    def tokenize(self) -> List[Token]:
        """Tokenize the entire source"""
        while self.current_char:
            start_line = self.line
            start_column = self.column
            
            # Skip whitespace (except newlines)
            if self.current_char in ' \t\r':
                self.skip_whitespace()
                continue
            
            # Handle newlines
            if self.current_char == '\n':
                self.tokens.append(Token(TokenType.NEWLINE, '\n', start_line, start_column))
                self.advance()
                continue
            
            # Handle comments
            if self.current_char == '~':
                self.skip_comment()
                continue
            
            # Handle strings
            if self.current_char in '"\'':
                quote = self.current_char
                value = self.read_string(quote)
                self.tokens.append(Token(TokenType.STRING, value, start_line, start_column))
                continue
            
            # Handle numbers
            if self.current_char.isdigit():
                value = self.read_number()
                self.tokens.append(Token(TokenType.NUMBER, value, start_line, start_column))
                continue
            
            # Handle identifiers and keywords
            if self.current_char.isalpha() or self.current_char == '_' or self.current_char == '#':
                value = self.read_identifier()
                token_type = self.get_token_type(value)
                self.tokens.append(Token(token_type, value, start_line, start_column))
                continue
            
            # Handle operators and delimiters
            if self.current_char == '(':
                self.tokens.append(Token(TokenType.LPAREN, '(', start_line, start_column))
                self.advance()
            elif self.current_char == ')':
                self.tokens.append(Token(TokenType.RPAREN, ')', start_line, start_column))
                self.advance()
            elif self.current_char == '{':
                self.tokens.append(Token(TokenType.LBRACE, '{', start_line, start_column))
                self.advance()
            elif self.current_char == '}':
                self.tokens.append(Token(TokenType.RBRACE, '}', start_line, start_column))
                self.advance()
            elif self.current_char == '[':
                self.tokens.append(Token(TokenType.LBRACKET, '[', start_line, start_column))
                self.advance()
            elif self.current_char == ']':
                self.tokens.append(Token(TokenType.RBRACKET, ']', start_line, start_column))
                self.advance()
            elif self.current_char == ',':
                self.tokens.append(Token(TokenType.COMMA, ',', start_line, start_column))
                self.advance()
            elif self.current_char == '.':
                self.tokens.append(Token(TokenType.DOT, '.', start_line, start_column))
                self.advance()
            elif self.current_char == ':':
                self.tokens.append(Token(TokenType.COLON, ':', start_line, start_column))
                self.advance()
            elif self.current_char == ';':
                self.tokens.append(Token(TokenType.SEMICOLON, ';', start_line, start_column))
                self.advance()
            elif self.current_char == '=' and self.peek() == '=':
                self.tokens.append(Token(TokenType.EQ, '==', start_line, start_column))
                self.advance()
                self.advance()
            elif self.current_char == '=':
                self.tokens.append(Token(TokenType.EQUALS, '=', start_line, start_column))
                self.advance()
            elif self.current_char == '+':
                self.tokens.append(Token(TokenType.PLUS, '+', start_line, start_column))
                self.advance()
            elif self.current_char == '-':
                self.tokens.append(Token(TokenType.MINUS, '-', start_line, start_column))
                self.advance()
            elif self.current_char == '*':
                self.tokens.append(Token(TokenType.STAR, '*', start_line, start_column))
                self.advance()
            elif self.current_char == '/' and self.peek() != '/':
                self.tokens.append(Token(TokenType.SLASH, '/', start_line, start_column))
                self.advance()
            elif self.current_char == '%':
                self.tokens.append(Token(TokenType.PERCENT, '%', start_line, start_column))
                self.advance()
            elif self.current_char == '!' and self.peek() == '=':
                self.tokens.append(Token(TokenType.NE, '!=', start_line, start_column))
                self.advance()
                self.advance()
            elif self.current_char == '!':
                self.tokens.append(Token(TokenType.NOT, '!', start_line, start_column))
                self.advance()
            elif self.current_char == '<' and self.peek() == '=':
                self.tokens.append(Token(TokenType.LE, '<=', start_line, start_column))
                self.advance()
                self.advance()
            elif self.current_char == '<':
                self.tokens.append(Token(TokenType.LT, '<', start_line, start_column))
                self.advance()
            elif self.current_char == '>' and self.peek() == '=':
                self.tokens.append(Token(TokenType.GE, '>=', start_line, start_column))
                self.advance()
                self.advance()
            elif self.current_char == '>':
                self.tokens.append(Token(TokenType.GT, '>', start_line, start_column))
                self.advance()
            elif self.current_char == '&' and self.peek() == '&':
                self.tokens.append(Token(TokenType.AND, '&&', start_line, start_column))
                self.advance()
                self.advance()
            elif self.current_char == '|' and self.peek() == '|':
                self.tokens.append(Token(TokenType.OR, '||', start_line, start_column))
                self.advance()
                self.advance()
            else:
                self.advance()
        
        self.tokens.append(Token(TokenType.EOF, '', self.line, self.column))
        return self.tokens

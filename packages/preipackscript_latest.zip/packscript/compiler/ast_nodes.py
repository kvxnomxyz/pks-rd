"""
PackScript AST (Abstract Syntax Tree) Node Definitions
"""
from dataclasses import dataclass
from typing import List, Dict, Any, Optional

@dataclass
class ASTNode:
    """Base class for all AST nodes"""
    pass

@dataclass
class Header(ASTNode):
    """Represents the #init header section"""
    modname: str
    modver: str
    override_game_files: bool
    packages: List[str] = None

@dataclass
class ScriptBlock(ASTNode):
    """Represents the #script section"""
    statements: List['Statement']

@dataclass
class Statement(ASTNode):
    """Base class for all statements"""
    pass

@dataclass
class FunctionCall(Statement):
    """Function call statement"""
    name: str
    arguments: List['Expression']

@dataclass
class Assignment(Statement):
    """Variable assignment"""
    var_name: str
    value: 'Expression'

@dataclass
class IfStatement(Statement):
    """If statement"""
    condition: 'Expression'
    then_block: List[Statement]
    else_block: Optional[List[Statement]] = None

@dataclass
class WhileStatement(Statement):
    """While loop"""
    condition: 'Expression'
    body: List[Statement]

@dataclass
class ForStatement(Statement):
    """For loop"""
    var_name: str
    start: 'Expression'
    end: 'Expression'
    body: List[Statement]

@dataclass
class SubscriptDef(Statement):
    """Subscript definition"""
    name: str
    parameters: List[str]
    body: List[Statement]

@dataclass
class TriggerDef(Statement):
    """Trigger definition"""
    name: str
    subscript_name: str
    conditions: Optional['Expression'] = None

@dataclass
class RunStatement(Statement):
    """Run statement"""
    target: 'Expression'

@dataclass
class ReturnStatement(Statement):
    """Return statement"""
    value: Optional['Expression'] = None

@dataclass
class ImportStatement(Statement):
    """Import statement"""
    package: str
    items: List[str]

@dataclass
class Expression(ASTNode):
    """Base class for expressions"""
    pass

@dataclass
class BinaryOp(Expression):
    """Binary operation"""
    left: Expression
    op: str
    right: Expression

@dataclass
class UnaryOp(Expression):
    """Unary operation"""
    op: str
    operand: Expression

@dataclass
class Literal(Expression):
    """Literal value"""
    value: Any
    type: str  # 'number', 'string', 'boolean'

@dataclass
class Variable(Expression):
    """Variable reference"""
    name: str

@dataclass
class MethodCall(Expression):
    """Method call expression"""
    name: str
    arguments: List[Expression]

@dataclass
class Program(ASTNode):
    """Root node of the program"""
    header: Header
    imports: List[ImportStatement]
    subscripts: List[SubscriptDef]
    triggers: List[TriggerDef]
    script: ScriptBlock

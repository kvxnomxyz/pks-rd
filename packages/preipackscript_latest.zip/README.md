# PackScript - Minecraft Modding Language

A domain-specific programming language for creating Minecraft plugins and mods using a simple, readable syntax. PackScript compiles to Java and integrates seamlessly with Minecraft Forge.

## Features

- **Simple Syntax**: Easy-to-learn language designed for Minecraft modding
- **Package System**: Built-in package management with Ducky
- **Code Reusability**: Import and use pre-made packages
- **Triggers**: Event-driven programming model
- **Variables & Types**: Dynamic variable system
- **Control Flow**: If/else, loops, functions
- **Real-Time Loading**: RawPKS for hot-reload development
- **Rapid Development**: Test without compilation

## Quick Start

### Installation (All-in-One Installer)

The easiest way to install PackScript is using the All-in-One installer:

```bash
# GUI Mode (Recommended - Visual interface)
python installer/aio_installer.py --gui

# CLI Mode (Remote servers, automation)  
python installer/aio_installer.py --cli

# Verbose Mode (Debugging)
python installer/aio_installer.py --gui --verbose
```

**What the installer does:**
- ✅ Verifies system requirements
- ✅ Downloads Ducky package manager
- ✅ Extracts to `~/.ducky` (all platforms)
- ✅ Configures environment variables
- ✅ Updates PATH for easy access
- ✅ Downloads package repository

**Installation takes:** 10-30 seconds (depends on internet speed)

For detailed installation guide, see [AIO_INSTALLER.md](AIO_INSTALLER.md)

### Your First PackScript

Create a file `hello.pks`:

```packscript
#init
modname(HelloMod)
modver(1.0.0)
overridegamefiles(false)

#script

log.print("Hello from PackScript!")
setvar(player_count, 0)
log.print(player_count)
```

Compile it:

```bash
pks hello.pks
```

This generates `hello.java` which you can integrate into your Minecraft mod.

## Language Syntax

### Header Section

Every PackScript file must start with a header:

```packscript
#init
modname(YourModName)
modver(1.0.0)
overridegamefiles(false)
packages(package1, package2)
```

### Script Section

The main execution code goes in the `#script` section:

```packscript
#script

log.print("This runs when the game starts")
```

### Variables

Use `setvar()` and `getvar()` for variables:

```packscript
setvar(count, 42)
getvar(count)
log.print(count)
```

### Control Flow

#### If Statements

```packscript
if(count > 10) {
    log.print("Count is high")
} else {
    log.print("Count is low")
}
```

#### Loops

```packscript
~ For loop
for i = 1 to 10 {
    log.print(i)
}

~ While loop
while(count < 5) {
    log.print(count)
    setvar(count, count + 1)
}
```

### Subscripts (Functions)

Define reusable code blocks:

```packscript
subscript.define(
    name(greet_player)
    parameters(player_name)
    script(
        log.print("Hello ")
        log.print(player_name)
    )
)
```

### Triggers

React to game events:

```packscript
trigger.add(
    name(on_join)
    subscript(greet_player)
)

#script
run(trigger(on_join))
```

### Imports & Packages

Use packages:

```packscript
#init
modname(MyMod)
modver(1.0.0)
overridegamefiles(false)
packages(easylog)

preload(
    import from(easylog) get(log_info, log_error)
)

#script
~ You can now use functions from easylog
```

### Built-in Functions

- `log.print(message)` - Print to console
- `setvar(name, value)` - Set a variable
- `getvar(name)` - Get a variable
- `chatlog(player)` - Log chat message
- `gamelog(message)` - Log game event

## Ducky Package Manager

Manage PackScript packages with Ducky.

### Commands

```bash
~ Install a package
ducky install easylog

~ Uninstall a package
ducky uninstall easylog

~ List installed packages
ducky list

~ Show package info
ducky show easylog

~ Search for packages
ducky search logging

~ Show repository info
ducky info
```

### Creating Packages

1. Create a package directory with `package.json`:

```json
{
  "name": "mypackage",
  "version": "1.0.0",
  "author": "Your Name",
  "description": "A useful package",
  "dependencies": [],
  "files": ["mypackage.pks"]
}
```

2. Add your PackScript files

3. Package it:

```bash
python packages/packager.py packages/mypackage
```

4. Upload to your repository

## Project Structure

```
packscript/
├── packscript/                 # PackScript language implementation
│   ├── compiler/               # Lexer, parser, code generator
│   └── cli/                    # Command-line interface (pks)
├── ducky/                      # Package manager
│   ├── package_manager.py      # Core package management
│   └── cli/                    # Package manager CLI (ducky)
├── rpks-runtime/               # Real-time script loader
│   ├── runtime.py              # Execution engine
│   └── cli.py                  # rpks CLI tool
├── installer/                  # Installation tools
│   ├── aio_installer.py        # All-in-One installer (CLI/GUI)
│   └── install.py              # Legacy installer
├── packages/                   # Sample packages
│   ├── rpks/                   # Real-time loader package
│   ├── easylog/               # Logging utilities
│   ├── chat/                  # Chat system
│   ├── player/                # Player utilities
│   └── packager.py            # Package creation tool
├── dist/                       # Compiled .acpg packages
│   ├── rpks.acpg              # Real-time loader
│   ├── easylog.acpg           # Logging library
│   ├── chat.acpg              # Chat system
│   ├── player.acpg            # Player utilities
│   └── ducky.zip.acpg         # Ducky installer
├── examples/                   # Example PackScript files
│   ├── hello_world.pks
│   ├── player_events.pks
│   ├── control_flow.pks
│   └── rawpks_demo.pks
└── documentation/              # Full documentation
    ├── README.md               # This file
    ├── AIO_INSTALLER.md        # All-in-One installer guide
    ├── LANGUAGE.md             # Language reference
    ├── DUCKY.md                # Package manager guide  
    ├── RAWPKS.md               # Real-time loader guide
    ├── ACPG_FORMAT.md          # .acpg package format
    ├── INSTALL.md              # Installation guide
    └── QUICKREF.md             # Quick reference
```

## Available Packages

### rpks (v1.0.0)
Real-time PackScript loader with hot-reload:
- `rpks start` - Start real-time loader
- `rpks run <file>` - Execute single script
- `rpks load` - Load all scripts
- Perfect for development and testing

### easylog (v1.0.0)
Logging utilities with different log levels:
- `log_info(message)` - Info level logging
- `log_error(message)` - Error level logging
- `log_debug(message)` - Debug level logging
- `log_warning(message)` - Warning level logging

### chat (v1.2.0)
Chat and messaging system:
- `send_player_message(player, message)` - Send message to player
- `send_global_message(message)` - Send message to all
- `send_warning(player, message)` - Send warning message
- `send_success(player, message)` - Send success message

### player (v1.1.0)
Player management utilities:
- `set_health(player, health)` - Set player health
- `get_health(player)` - Get player health
- `add_item(player, item, count)` - Add item to inventory
- `get_inventory(player)` - Get player inventory
- `give_experience(player, amount)` - Give experience

## Repository Configuration

The default package repository is configured at:
```
https://raw.githubusercontent.com/kvxnomxyz/pks-rd/package-repositories.json
```

## Examples

See the `examples/` folder for PackScript examples:
- `hello_world.pks` - Basic hello world
- `player_events.pks` - Player event handling
- `control_flow.pks` - Control flow examples
- `rawpks_demo.pks` - RawPKS real-time loader demo

## Documentation

**Getting Started:**
- **[AIO_INSTALLER.md](AIO_INSTALLER.md)** - All-in-One installer guide (recommended)
- **[INSTALL.md](INSTALL.md)** - Installation options and troubleshooting

**Core Documentation:**
- **[LANGUAGE.md](LANGUAGE.md)** - Complete language reference  
- **[DUCKY.md](DUCKY.md)** - Package manager guide
- **[RAWPKS.md](RAWPKS.md)** - Real-time development loader
- **[ACPG_FORMAT.md](ACPG_FORMAT.md)** - Advanced Compressed Package format

**Quick Reference:**
- **[QUICKREF.md](QUICKREF.md)** - Quick reference guide
- **examples/** - Working example scripts

## Building from Source

```bash
~ Compile PackScript files
pks examples/hello_world.pks

~ Execute with real-time loader
rpks run examples/hello_world.pks

~ The output is a .java file ready to integrate into your mod
```

## Architecture

### PackScript Compiler

1. **Lexer** (`compiler/lexer.py`) - Tokenizes source code
2. **Parser** (`compiler/parser.py`) - Creates Abstract Syntax Tree
3. **Codegen** (`compiler/codegen.py`) - Generates Java code
4. **Compiler** (`compiler/compiler.py`) - Main interface

### Ducky Package Manager

1. **Package Manager** (`ducky/package_manager.py`) - Core functionality
   - Package registry
   - Installation/uninstallation
   - Dependency management

2. **Package Downloader** - Fetches packages from repositories

3. **CLI Interface** (`ducky/cli/ducky.py`) - Command-line tool

### RawPKS Real-Time Loader

1. **Runtime Engine** (`rpks-runtime/runtime.py`) - Execution environment
   - File watching and hot-reload
   - Script loading and execution
   - Variable management
   - Trigger and subscript handling

2. **CLI Interface** (`rpks-runtime/cli.py`) - Command-line tool
   - `rpks start` - Real-time loader
   - `rpks run` - Execute scripts
   - `rpks status` - Show status

## Workflow Options

### Traditional Compilation Flow
```
.pks file → pks compiler → .java file → Minecraft Forge
```

### Real-Time Development Flow
```
.pks file → rpks loader → Instant execution → Hot-reload on save
```

### Hybrid Development
```
rpks run mymod.pks  (test/develop)
    ↓
pks mymod.pks       (compile when ready)
    ↓
use with Minecraft  (deploy)
```

## Contributing

PackScript is open source! To contribute:

1. Fork the repository
2. Create your feature branch
3. Submit a pull request

## License

PackScript is released under CC0-1.0 (Public Domain)

## Support

For issues, questions, or feature requests:
- Check the examples folder
- Review the language documentation
- Visit the GitHub repository

## Roadmap

- [ ] Standard library expansion
- [ ] Debugging tools
- [ ] IDE plugins (VS Code, IntelliJ)
- [ ] Package signing and verification
- [ ] More built-in functions
- [ ] Compilation optimization
- [ ] Documentation website

---

Happy modding with PackScript! 🚀
